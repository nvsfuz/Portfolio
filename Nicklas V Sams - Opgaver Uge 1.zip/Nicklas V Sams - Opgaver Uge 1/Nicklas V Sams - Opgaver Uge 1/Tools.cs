﻿using System;

namespace Nicklas_V_Sams___Opgaver_Uge_1
{
    class Tools
    {
        public static int GreatestInt(int bogbig, int bigbog)
        {
            int boggest = Math.Max(bogbig, bigbog);
            return boggest;
        }

        public static double GreatestDouble(double bang, double bing)
        {
            double boggest = Math.Max(bang, bing);
            return boggest;
        }

        public static string GreatestString(string sim, string sam)
        {
            int boggestStrong = Math.Max(sim.Length, sam.Length);
            if (boggestStrong == sim.Length && boggestStrong == sam.Length)
            {
                return "Begge strings er lige lange!";
            }
            else if (boggestStrong == sim.Length)
            {
                return "Den indtastede string med den største længde er" +
                    ": " + sim;
            }
            else if (boggestStrong == sam.Length)
            {
                return "Den indtastede string med den største længde er" +
                    ": " + sam;
            }
            return null;
        }

        public static void Swap(int swipin, int swupin, out int swip, out int swup)
        {
            int swipswap = swipin;
            int swupswap = swupin;

            swip = swupswap;
            swup = swipswap;
        }
    }
}
