﻿using System;
using System.Linq;
using static System.Console;
using System.Text.RegularExpressions;
using System.Globalization;

namespace Nicklas_V_Sams___Opgaver_Uge_1
{
    class Program
    {
        static void Main(string[] args)
        {
            #region intro
            Write("Hej Willy, jeg har besluttet at samle alle opgaverne i et program. Forhåbentligt virker det hele!\nDer er desværre ikke kommentarer til, da jeg kun har en time tilbage til vi har fri,\nellers havde der selvfølgelig været kommentarer til det hele!");
            ReadKey();
            Clear();
            #endregion

            #region Initialisering af variabler
            Ugedage dagMandag = Ugedage.mandag,
                dagTirsdag = Ugedage.tirsdag,
                dagOnsdag = Ugedage.onsdag,
                dagTorsdag = Ugedage.torsdag,
                dagFredag = Ugedage.fredag,
                dagLørdag = Ugedage.lørdag,
                dagSøndag = Ugedage.søndag;

            BeerType lager = BeerType.lager,
                pilsner = BeerType.pilsner,
                münchener = BeerType.münchener,
                wiener = BeerType.wiener,
                dortmunder = BeerType.dortmunder,
                bock = BeerType.bock,
                dobbelBock = BeerType.dobbelbock,
                porter = BeerType.porter;

            string minDag = "", whichAssign;
            #endregion

            #region Opgavevalg & Switch
            do
            {
                Console.WriteLine();
                Console.Clear();
                Console.WriteLine("Menu 1: Ugedage \nMenu 2: Ølopgaver\nMenu 3: Kapitel 1\nMenu 4: Kapitel 2\nMenu 5: Kapitel 3(Delvist)\nMenu 6: Kapitel 4\nMenu 7: Kapitel 4-2\nMenu 8: Kapitel 5\nMenu 9: Metoder");
                Console.Write("Hvilken opgave vil du se? (Vælgt et tal): ");
                whichAssign = Console.ReadLine();
                switch (whichAssign)
                {
                    #region Case 1 - Ugedage Enum
                    case "1":
                        Console.Clear();
                        Console.Write("Indtast en dag: ");
                        minDag = Console.ReadLine().ToLower();
                        if (minDag == dagMandag.ToString())
                        {
                            HvilkenDag(dagMandag);
                        }
                        else if (minDag == dagTirsdag.ToString())
                        {
                            HvilkenDag(dagTirsdag);
                        }
                        else if (minDag == dagOnsdag.ToString())
                        {
                            HvilkenDag(dagOnsdag);
                        }
                        else if (minDag == dagTorsdag.ToString())
                        {
                            HvilkenDag(dagTorsdag);
                        }
                        else if (minDag == dagFredag.ToString())
                        {
                            HvilkenDag(dagFredag);
                        }
                        else if (minDag == dagLørdag.ToString())
                        {
                            HvilkenDag(dagLørdag);
                        }
                        else if (minDag == dagSøndag.ToString())
                        {
                            HvilkenDag(dagSøndag);
                        }
                        else { Console.Write("Din indtastning er forkert, prøv igen."); Console.ReadKey(); }
                        break;
                    #endregion

                    #region Case 2 - Ølopgaver Kap. 3 & 7
                    case "2":
                        string ølValgSwitch;
                        do
                        {
                            Console.Clear();
                            Console.Write("Enum: 1\nMetoder: 2\nVælg: ");
                            ølValgSwitch = Console.ReadLine();

                            switch (ølValgSwitch)
                            {
                                #region Øltype enum opgave
                                case "1":
                                    Clear();
                                    Console.WriteLine(lager.ToString() + " er defineret som nummer " + (byte)lager);
                                    Console.WriteLine(pilsner.ToString() + " er defineret som nummer " + (byte)pilsner);
                                    Console.WriteLine(münchener.ToString() + " er defineret som nummer " + (byte)münchener);
                                    Console.WriteLine(wiener.ToString() + " er defineret som nummer " + (byte)wiener);
                                    Console.WriteLine(dortmunder.ToString() + " er defineret som nummer " + (byte)dortmunder);
                                    Console.WriteLine(bock.ToString() + " er defineret som nummer " + (byte)bock);
                                    Console.WriteLine(dobbelBock.ToString() + " er defineret som nummer " + (byte)dobbelBock);
                                    Console.WriteLine(porter.ToString() + " er defineret som nummer " + (byte)porter);
                                    WriteLine();
                                    Console.WriteLine("Indtast nummer!");
                                    Console.Write("Vælg en øltype for at få mere information: ");
                                    byte ølValg = byte.Parse(Console.ReadLine());
                                    if (ølValg == (byte)lager)
                                    {
                                        HvilkenØl(lager);
                                    }
                                    else if (ølValg == (byte)pilsner)
                                    {
                                        HvilkenØl(pilsner);
                                    }
                                    else if (ølValg == (byte)münchener)
                                    {
                                        HvilkenØl(münchener);
                                    }
                                    else if (ølValg == (byte)wiener)
                                    {
                                        HvilkenØl(wiener);
                                    }
                                    else if (ølValg == (byte)dortmunder)
                                    {
                                        HvilkenØl(dortmunder);
                                    }
                                    else if (ølValg == (byte)bock)
                                    {
                                        HvilkenØl(bock);
                                    }
                                    else if (ølValg == (byte)dobbelBock)
                                    {
                                        HvilkenØl(dobbelBock);
                                    }
                                    else if (ølValg == (byte)porter)
                                    {
                                        HvilkenØl(porter);
                                    }
                                    else { Console.Write("Din indtastning er forkert, prøv igen."); Console.ReadKey(); }
                                    break;
                                #endregion

                                #region Øltype struct og metode opgave
                                case "2":
                                    string øL;
                                    do
                                    {
                                        Console.Clear();
                                        Console.Write("Forskellige slags øl: lager - pilsner - münchener - wiener - dortmunder - bock - dobbelbock - porter \nVælg en øl(indtast navn og tryk enter): ");
                                        øL = Console.ReadLine().ToLower();
                                        if (øL != BeerType.lager.ToString() &&
                                            øL != BeerType.pilsner.ToString() &&
                                            øL != BeerType.münchener.ToString() &&
                                            øL != BeerType.wiener.ToString() &&
                                            øL != BeerType.dortmunder.ToString() &&
                                            øL != BeerType.bock.ToString() &&
                                            øL != BeerType.dobbelbock.ToString() &&
                                            øL != BeerType.porter.ToString())
                                        {
                                            Console.Write("Din indtastning er forkert, prøv igen.");
                                            øL = null;
                                            Console.ReadKey();
                                        }

                                    } while (øL == null);
                                    switch (øL)
                                    {
                                        case "lager":
                                            Console.Write(GetBeerStr(beer1));
                                            break;
                                        case "pilsner":
                                            Console.Write(GetBeerStr(beer2));
                                            break;
                                        case "münchener":
                                            Console.Write(GetBeerStr(beer3));
                                            break;
                                        case "wiener":
                                            Console.Write(GetBeerStr(beer4));
                                            break;
                                        case "dortmunder":
                                            Console.Write(GetBeerStr(beer5));
                                            break;
                                        case "bock":
                                            Console.Write(GetBeerStr(beer6));
                                            break;
                                        case "dobbelbock":
                                            Console.Write(GetBeerStr(beer7));
                                            break;
                                        case "porter":
                                            Console.Write(GetBeerStr(beer8));
                                            break;
                                    }
                                    Console.ReadKey();
                                    break;
                                default:

                                    Console.Write("Indtast 1 eller 2 og tryk enter");
                                    Console.ReadKey();
                                    break;
                            }
                        } while (ølValgSwitch != "1" && ølValgSwitch != "2");

                        break;
                    #endregion
                    #endregion

                    #region Case 3 - Kapitel 1 Opgaver
                    case "3":

                    start: Console.Clear();
                        double deciTal1 = 0, deciTal2 = 0, deciTal3 = 0;
                        int tal1 = 0, tal2 = 0;
                        Console.Write("Indtast dit navn: ");
                        string navn = Console.ReadLine();
                        if (IsValid(navn) == false)
                        {
                            Console.Write("Dit navn må kun indeholde bogstaver!");
                            Console.ReadKey();
                            goto start;
                        }

                        Console.WriteLine("Goddag " + navn);
                        Console.ReadKey();
                    startInt: Console.Clear();
                        try
                        {
                            Console.Write("Indtast ét helt tal: ");
                            tal1 = int.Parse(Console.ReadLine());
                        }
                        catch (Exception ex)
                        {
                            Console.Write("Indtast venligst et helt tal!");
                            Console.ReadKey();
                            goto startInt;
                        }
                        try
                        {
                            Console.Write("Indtast endnu ét helt tal: ");
                            tal2 = int.Parse(Console.ReadLine());
                        }
                        catch (Exception ex)
                        {
                            Console.Write("Indtast venligst et helt tal!");
                            Console.ReadKey();
                            goto startInt;
                        }
                        Console.WriteLine("Den sammenlagte værdi af tallene er: " + (tal1 + tal2));
                        Console.WriteLine();
                        Console.ReadKey();
                    startDeci: Console.Clear();
                        try
                        {
                            Console.Write("Indtast et decimaltal: ");
                            deciTal1 = double.Parse(Console.ReadLine());
                        }
                        catch
                        {
                            Console.Write("Din indtastning skal være et tal!");
                            Console.ReadKey();
                            goto startDeci;
                        }
                        try
                        {
                            Console.Write("Indtast et andet decimaltal: ");
                            deciTal2 = double.Parse(Console.ReadLine());
                        }
                        catch
                        {
                            Console.Write("Din indtastning skal være et tal!");
                            Console.ReadKey();
                            goto startDeci;
                        }
                        try
                        {
                            Console.Write("Indtast et tredje decimaltal: ");
                            deciTal3 = double.Parse(Console.ReadLine());
                        }
                        catch
                        {
                            Console.Write("Din indtastning skal være et tal!");
                            Console.ReadKey();
                            goto startDeci;
                        }
                        double[] sum1 = { deciTal1, deciTal2, deciTal3 };
                        double sumValue = sum1.Sum();
                        Console.Write("Summen af tallene er: " + sumValue);
                        Console.ReadKey();
                        break;
                    #endregion

                    #region Case 4 - Kapitel 2 Opgaver
                    case "4":
                        decimal dec = 0;
                        do
                        {
                            Console.Clear();
                            try
                            {
                                Console.Write("Indtast en decimal værdi: ");
                                dec = decimal.Parse(Console.ReadLine());
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine("Den indtastede værdi skal være et tal.");
                                Console.ReadKey();
                            }
                        }
                        while (dec == 0);
                        decimal decAfrund = Math.Round(dec);
                        int intAfrund = (int)decAfrund;
                        Console.WriteLine("Når decimaltallet er afrundet, får vi tallet: " + intAfrund);
                        Console.WriteLine("Når decimaltallet er afrundet til 2 decimaler, får vi tallet: " + Math.Round(dec, 2));

                        decimal closeHundred = Math.Round(dec / 100, 0);
                        closeHundred = closeHundred * 100;
                        if (closeHundred == 0)
                        {
                            closeHundred = 100;
                        }
                        Console.WriteLine("Afrundet til nærmeste 100, får vi tallet: " + closeHundred);

                        string binary = Convert.ToString(intAfrund, 2);
                        Console.WriteLine("Når vi konverterer vores heltal til binær, får vi tallet: " + binary);

                        string hexValue = intAfrund.ToString("X");
                        Console.WriteLine("Når vi konverterer vores heltal til hex, får vi tallet: " + hexValue);

                        int intAgain = int.Parse(hexValue, System.Globalization.NumberStyles.HexNumber);
                        Console.WriteLine("Når vi konverterer vores hex tilbage til heltal, får vi: " + intAgain);

                        int intAgain2 = Convert.ToInt32(binary, 2);
                        Console.WriteLine("Når vi konverterer vores binære værdi tilbage til heltal, får vi: " + intAgain2);

                        Console.ReadKey();
                        break;
                    #endregion

                    #region Case 5 - Kapitel 3-2 Opgaver
                    case "5":
                        Clear();
                        NumberFormatInfo nfi = new CultureInfo("en-US", false).NumberFormat;
                        nfi.CurrencyDecimalSeparator = ",";
                        nfi.CurrencyGroupSeparator = ".";
                        nfi.CurrencySymbol = "";
                        string choice = null;
                        do
                        {
                            Clear();
                            Console.WriteLine("konto1 - konto2 - konto3");
                            Console.WriteLine("Indtast navnet på den konto du gerne vil se: ");
                            choice = Console.ReadLine();
                            if (choice != "konto1" && choice != "konto2" && choice != "konto3")
                            {
                                Write("Din indtastning er forket! Prøv igen! - \n[Hint: Indtast 'konto1' for at se konto1]");
                                ReadKey();
                            }
                        }
                        while (choice != "konto1" && choice != "konto2" && choice != "konto3");
                        Clear();
                        Console.Write(UdskrivAccount(choice));
                        Console.ReadKey();
                        break;
                    #endregion

                    #region Case 6 - Kapitel 4 Opgaver
                    case "6":
                        Clear();
                        OpgaveString();
                        CPRString();
                        string name = null;
                        do
                        {
                            Console.Clear();
                            Console.WriteLine("Denne opgave giver mest mening hvis du skriver dit navn med en blanding af store og små bogstaver!\nPrøv også bindestreg i dit navn!");
                            Console.Write("Indtast dit navn (Maks 3 navne): ");
                            name = Console.ReadLine();
                            Console.Write("Dit navn er nu formateret med store og små bogstaver som: " + Navn(name));
                            Console.ReadKey();
                        }
                        while (Navn(name).ToString() == "Der kan maks indtastes 3 navne!" || Navn(name).ToString() == "nothing" || name == null);
                        break;
                    #endregion

                    #region Case 7 - Kapitel 4-2 Opgaver
                    case "7":
                        Clear();
                        ArrayString();
                        ArrayDimensional();
                        ReadKey();
                        break;
                    #endregion

                    #region Case 8 - Kapitel 5 opgave
                    case "8":
                        Clear();
                        for (int i = 0; i < 10; i++)
                        {
                            for (int j = 0; j < 10; j++)
                            {
                                Write((i * 10 + j).ToString().PadLeft(3));
                            }
                            WriteLine();
                        }
                        ReadKey();
                        break;
                    #endregion

                    #region Case 9 - Metoder
                    case "9":
                        int bogbig = 0, bigbog = 0, swap1 = 0, swap2 = 0;
                        double dubdib = 0, dibdub = 0;
                        string sabseb = "", sebsab = "";
                        bool tjek = false;
                        do
                        {
                            Clear();
                            try
                            {
                                Write("Indtast ét heltal: ");
                                bogbig = int.Parse(ReadLine());

                                Write("Indtast endnu ét heltal: ");
                                bigbog = int.Parse(ReadLine());
                            }
                            catch (FormatException ex)
                            {
                                Write("Fejl: " + ex.Message + "\nPrøv igen - Dit tal skal være et heltal!");
                                ReadKey();
                                continue;
                            }

                            try
                            {
                                Write("Indtast ét decimaltal: ");
                                dubdib = double.Parse(ReadLine());

                                Write("Indtast endnu ét decimaltal: ");
                                dibdub = double.Parse(ReadLine());

                                tjek = true;
                            }
                            catch (FormatException ex)
                            {
                                Write("Fejl: " + ex.Message + "\nPrøv igen - Dit input skal være et tal!");
                                ReadKey();
                                continue;
                            }

                        } while (!tjek);
                        Write("Indtast noget tekst: ");
                        sebsab = ReadLine();
                        Write("Indtast én tekst mere: ");
                        sabseb = ReadLine();
                        try
                        {
                            Write("Indtast ét heltal til variablen swap1: ");
                            swap1 = int.Parse(ReadLine());
                            Write("Indtast endnu ét heltal til variablen swap2: ");
                            swap2 = int.Parse(ReadLine());

                            Tools.Swap(swap1, swap2, out swap1, out swap2);
                        }
                        catch (FormatException ex)
                        {
                            WriteLine();
                            Write("Fejl: " + ex.Message + "\nIndtast kun heltal!");
                            ReadKey();
                        }
                        Clear();
                        WriteLine("Dette er det største af de 2 heltal: " + Tools.GreatestInt(bogbig, bigbog));
                        WriteLine("Dette er det største af de 2 decimaler: " + Tools.GreatestDouble(dibdub, dubdib));
                        WriteLine(Tools.GreatestString(sabseb, sebsab));
                        Write("Vores variabler swap1 og swap2 har nu byttet værdi!\nswap1: " + swap1.ToString() + "\nswap2: " + swap2.ToString());
                        
                        ReadKey();
                        break;
                    #endregion

                    #region slut
                    default:
                        if (whichAssign != "quit")
                        {
                            Console.Write("Forkert indtastning!");
                            Console.ReadKey();
                        }
                        break;
                }
            }
            while (whichAssign != "quit");
            Console.Write("Farvel.");
            Console.ReadKey();

            
        }
        #endregion
        #endregion

        /// <summary>
        /// Her ligger metode og enum relateret til ugedage
        /// </summary>
        #region Ugedage
        public enum Ugedage
        {
            mandag = 1, tirsdag, onsdag, torsdag, fredag, lørdag, søndag
        }
        public static void HvilkenDag(Ugedage dage)
        {
            string[] dayOfWeek = new string[] {
                DayOfWeek.Monday.ToString(),
                DayOfWeek.Tuesday.ToString(),
                DayOfWeek.Wednesday.ToString(),
                DayOfWeek.Thursday.ToString(),
                DayOfWeek.Friday.ToString(),
                DayOfWeek.Saturday.ToString(),
                DayOfWeek.Sunday.ToString()
            };


            switch (dage)
            {
                case Ugedage.mandag:
                    Console.WriteLine("Today it is {0}, the {1}. day of the week.", dayOfWeek[(int)dage - 1], (int)dage);
                    Console.ReadKey();
                    break;
                case Ugedage.tirsdag:
                    Console.WriteLine("Today it is {0}, the {1}. day of the week.", dayOfWeek[(int)dage - 1], (int)dage);
                    Console.ReadKey();
                    break;
                case Ugedage.onsdag:
                    Console.WriteLine("Today it is {0}, the {1}. day of the week.", dayOfWeek[(int)dage - 1], (int)dage);
                    Console.ReadKey();
                    break;
                case Ugedage.torsdag:
                    Console.WriteLine("Today it is {0}, the {1}. day of the week.", dayOfWeek[(int)dage - 1], (int)dage);
                    Console.ReadKey();
                    break;
                case Ugedage.fredag:
                    Console.WriteLine("Today it is {0}, the {1}. day of the week.", dayOfWeek[(int)dage - 1], (int)dage);
                    Console.ReadKey();
                    break;
                case Ugedage.lørdag:
                    Console.WriteLine("Today it is {0}, the {1}. day of the week. This is a weekend!", dayOfWeek[(int)dage - 1], (int)dage);
                    Console.ReadKey();
                    break;
                case Ugedage.søndag:
                    Console.WriteLine("Today it is {0}, the {1}. day of the week. This is a weekend!", dayOfWeek[(int)dage - 1], (int)dage);
                    Console.ReadKey();
                    break;
            }
        }
        #endregion

        /// <summary>
        /// Her ligger ølrelaterede metoder, enums og structs.
        /// </summary>
        #region Øl

        #region enum og struct
        public enum BeerType
        {
            lager = 1, pilsner, münchener, wiener, dortmunder, bock, dobbelbock, porter
        }
        public struct Beer
        {
            public string Fabrikat;
            public string Type;
            public double Procent;
            public double Volume;
        }
        #endregion

        #region metoder
        public static void HvilkenØl(BeerType beer)
        {
            Console.Clear();
            switch (beer)
            {

                case BeerType.lager:
                    Console.Write("Fabrikat: " + beer1.Fabrikat +
                        "\nØltype: " + beer1.Type +
                        "\nVolumen: " + beer1.Volume +
                        "\nProcent: " + beer1.Procent);
                    Console.ReadKey();
                    break;
                case BeerType.pilsner:
                    Console.Write("Fabrikat: " + beer2.Fabrikat +
                        "\nØltype: " + beer2.Type +
                        "\nVolumen: " + beer2.Volume +
                        "\nProcent: " + beer2.Procent);
                    Console.ReadKey();
                    break;
                case BeerType.münchener:
                    Console.Write("Fabrikat: " + beer3.Fabrikat +
                        "\nØltype: " + beer3.Type +
                        "\nVolumen: " + beer3.Volume +
                        "\nProcent: " + beer3.Procent);
                    Console.ReadKey();
                    break;
                case BeerType.wiener:
                    Console.Write("Fabrikat: " + beer4.Fabrikat +
                        "\nØltype: " + beer4.Type +
                        "\nVolumen: " + beer4.Volume +
                        "\nProcent: " + beer4.Procent);
                    Console.ReadKey();
                    break;
                case BeerType.dortmunder:
                    Console.Write("Fabrikat: " + beer5.Fabrikat +
                        "\nØltype: " + beer5.Type +
                        "\nVolumen: " + beer5.Volume +
                        "\nProcent: " + beer5.Procent);
                    Console.ReadKey();
                    break;
                case BeerType.bock:
                    Console.Write("Fabrikat: " + beer6.Fabrikat +
                        "\nØltype: " + beer6.Type +
                        "\nVolumen: " + beer6.Volume +
                        "\nProcent: " + beer6.Procent);
                    Console.ReadKey();
                    break;
                case BeerType.dobbelbock:
                    Console.Write("Fabrikat: " + beer7.Fabrikat +
                        "\nØltype: " + beer7.Type +
                        "\nVolumen: " + beer7.Volume +
                        "\nProcent: " + beer7.Procent);
                    Console.ReadKey();
                    break;
                case BeerType.porter:
                    Console.Write("Fabrikat: " + beer8.Fabrikat +
                        "\nØltype: " + beer8.Type +
                        "\nVolumen: " + beer8.Volume +
                        "\nProcent: " + beer8.Procent);
                    Console.ReadKey();
                    break;
            }
        }
        static string GetBeerStr(Beer beer)
        {
            if (beer.Type == "lager" ||
                beer.Type == "pilsner" ||
                beer.Type == "münchener" ||
                beer.Type == "wiener" ||
                beer.Type == "dortmunder" ||
                beer.Type == "bock" ||
                beer.Type == "dobbelbock" ||
                beer.Type == "porter")
            {
                return "Den valgte øl er en " + beer.Type + ". \nDen er produceret af " + beer.Fabrikat + ". \nAlkoholprocenten er " + beer.Procent.ToString() + "% og volumen er " + beer.Volume.ToString() + ".";
            }
            else
            {
                return ""; // Mandatory return
            }
        }
        #endregion

        #region Beerstructs
        public static Beer beer1 = new Beer
        {
            Fabrikat = "Carlsberg",
            Type = BeerType.lager.ToString(),
            Procent = 7,
            Volume = 15
        };

        public static Beer beer2 = new Beer
        {
            Fabrikat = "Tuborg",
            Type = BeerType.pilsner.ToString(),
            Procent = 9,
            Volume = 14
        };

        public static Beer beer3 = new Beer
        {
            Fabrikat = "Harboe",
            Type = BeerType.münchener.ToString(),
            Procent = 10,
            Volume = 5
        };

        public static Beer beer4 = new Beer
        {
            Fabrikat = "Brewdog",
            Type = BeerType.wiener.ToString(),
            Procent = 3,
            Volume = 20
        };

        public static Beer beer5 = new Beer
        {
            Fabrikat = "Heineken",
            Type = BeerType.dortmunder.ToString(),
            Procent = 4,
            Volume = 14.5
        };

        public static Beer beer6 = new Beer
        {
            Fabrikat = "Castel Beer",
            Type = BeerType.bock.ToString(),
            Procent = 20.9,
            Volume = 1
        };

        public static Beer beer7 = new Beer
        {
            Fabrikat = "Kirin",
            Type = BeerType.dobbelbock.ToString(),
            Procent = 1,
            Volume = 55
        };

        public static Beer beer8 = new Beer
        {
            Fabrikat = "Coors",
            Type = BeerType.porter.ToString(),
            Procent = 0.1,
            Volume = 200
        };
        #endregion
        #endregion

        /// <summary>
        /// Bool der tjekker hvorvidt der kun er bogstaver i det indtastede navn
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        #region Kapitel 1 bool
        private static bool IsValid(String str)
        {
            bool valid = false;
            if (Regex.IsMatch(str, @"^[a-zA-Z øØåÅæÆ]+$"))
            {
                valid = true;
            }

            return valid;
        }
        #endregion

        /// <summary>
        /// En struct og en metode der lagrer og returnerer værdier lagret i structs
        /// </summary>
        #region Kapitel 2 & 3-2 struct og metode
        public struct Account
        {
            public string navn;
            public string nrCPR;
            public double saldo;
        }
        public static string UdskrivAccount(string help)
        {
            Account konto1, konto2, konto3;
            konto1.navn = "Jørgen";
            konto1.nrCPR = "280666-6969";
            konto1.saldo = 273.5;

            konto2.navn = "Henrik";
            konto2.nrCPR = "151053-6006";
            konto2.saldo = 3;

            konto3.navn = "Peder";
            konto3.nrCPR = "011086-2043";
            konto3.saldo = 1095003;



            switch (help)
            {
                case "konto1":
                    return "Navn: " + konto1.navn + "\nCPR Nummer: " + konto1.nrCPR + "\nSaldo: " + konto1.saldo.ToString();

                case "konto2":
                    return "Navn: " + konto2.navn + "\nCPR Nummer: " + konto2.nrCPR + "\nSaldo: " + konto2.saldo.ToString();

                case "konto3":
                    return "Navn: " + konto3.navn + "\nCPR Nummer: " + konto3.nrCPR + "\nSaldo: " + konto3.saldo.ToString();

                default:
                    Console.Write("Try again tyvm");
                    break;
            }
            return null;
        }
        #endregion

        /// <summary>
        /// CPR Tjek - Tjekker om modulus 11 reglen gælder for det indtastede CPR-nummer
        /// String manipulering - Ændrer/Sletter/Tilføjer/Finder værdier i vores string
        /// Navneformatering - Sørger for at det indtastede navn er formateret korrekt med store og små bogstaver
        /// </summary>
        #region Kapitel 4 metoder - CPR Tjek - String manipulering - Navneformatering
        static void CPRString()
        {
            Console.Clear();
            Console.WriteLine("Udarbejdning af en CPR-tjekker");
            string cpr = "";
            while (Legit(cpr) == false)
            {
                Console.WriteLine("Format: ddmmyy-xxxx");
                Console.Write("Indtast CPR-nummer: ");
                cpr = Console.ReadLine();

                if (Legit(cpr) == true)
                {
                    if (int.Parse(cpr[10].ToString()) % 2 == 0)
                    {
                        Console.Write("CPR-nummeret er gyldigt! Du er en kvinde!");
                    }
                    else Console.Write("CPR-nummeret er gyldigt! Du er en mand!");
                    Console.Write("\nSuccess.");
                }
                else
                {
                    Console.Write("Error occured");
                    Console.ReadKey();
                    Console.Clear();
                }
            }
            Console.ReadKey();
        }
        static void OpgaveString()
        {
            Console.WriteLine("Udarbejdning og ændring af en string.");
            string opgave = "Nu kan det da vist ikke gøres meget bedre";
            Console.WriteLine("Original string: " + opgave);
            Console.WriteLine("Startpositionen af 'det' er: " + opgave.IndexOf("det"));
            Console.WriteLine("Ændret string: " + opgave.Remove(14, 5).Insert(24, " ret").Trim());
            string opgaveX = opgave.Remove(14, 5).Insert(24, " ret").Trim().ToLower();
            Console.WriteLine("Udskrift af karakter på indeks placering 15 af original string: " + opgave[15]);
            Console.WriteLine("Udskrift af karakter på indeks placering 15 af ændret string: " + opgaveX[15]);
            Console.ReadKey();
        }
        static bool Legit(string legitString)
        {
            bool isFirst = false;
            bool isLast = false;
            try
            {
                string firstPart = legitString.Substring(0, 6);
                string lastPart = legitString.Substring(7, 4);
                string dayCheck = legitString.Substring(0, 2);
                string monthCheck = legitString.Substring(2, 2);
                foreach (char c in firstPart)
                {
                    if (c >= '0' && c <= '9')
                    {
                        isFirst = true;
                    }
                    else
                    {
                        isFirst = false;
                        break;
                    }
                }
                foreach (char c in lastPart)
                {
                    if (c >= '0' && c <= '9')
                    {
                        isLast = true;
                    }
                    else
                    {
                        isLast = false;
                        break;
                    }
                }

                if (legitString.Length == 11
                    && legitString[6].ToString() == "-"
                    && isFirst == true
                    && isLast == true
                    && int.Parse(dayCheck) >= 0
                    && int.Parse(dayCheck) <= 31
                    && int.Parse(monthCheck) >= 1
                    && int.Parse(monthCheck) <= 12)
                {
                    double[] modulus11 = new double[10];
                    modulus11[0] = double.Parse(legitString[0].ToString()) * 4;
                    modulus11[1] = double.Parse(legitString[1].ToString()) * 3;
                    modulus11[2] = double.Parse(legitString[2].ToString()) * 2;
                    modulus11[3] = double.Parse(legitString[3].ToString()) * 7;
                    modulus11[4] = double.Parse(legitString[4].ToString()) * 6;
                    modulus11[5] = double.Parse(legitString[5].ToString()) * 5;
                    modulus11[6] = double.Parse(legitString[7].ToString()) * 4;
                    modulus11[7] = double.Parse(legitString[8].ToString()) * 3;
                    modulus11[8] = double.Parse(legitString[9].ToString()) * 2;
                    modulus11[9] = double.Parse(legitString[10].ToString()) * 1;



                    double modulusSum = modulus11.Sum() % 11;
                    if (modulusSum == 0)
                    {
                        return true;
                    }
                }
            }
            catch
            {

            }


            return false;
        }
        static string Navn(string theSting)
        {
            string Fornavn = null;
            string Mellemnavn = null;
            string Efternavn = null;
            int finddash;
            for (int i = 0; i < theSting.Length; i++)
            {
                string F = theSting.Substring(i, 1);
                Fornavn += F;
                if (theSting.Substring(i, 1) == " ")
                {
                    for (int t = i + 1; t < theSting.Length; t++)
                    {
                        string M = theSting.Substring(t, 1);
                        Mellemnavn += M;
                        if (theSting.Substring(t, 1) == " ")
                        {
                            for (int p = t + 1; p < theSting.Length; p++)
                            {
                                string E = theSting.Substring(p, 1);
                                Efternavn += E;
                                if (theSting.Substring(p, 1) == " ")
                                {
                                    return "Der kan maks indtastes 3 navne!";
                                }
                            }
                            break;
                        }
                    }
                    break;
                }
            }

            if (Fornavn != null && Mellemnavn != null && Efternavn == null)
            {
                Efternavn = Mellemnavn;
                Fornavn = Fornavn.First().ToString().ToUpper() + Fornavn.Substring(1).ToLower();
                Efternavn = Efternavn.First().ToString().ToUpper() + Efternavn.Substring(1).ToLower();
                return Fornavn + Efternavn;
            }
            else if (Fornavn != null && Mellemnavn != null && Efternavn != null)
            {
                Fornavn = Fornavn.First().ToString().ToUpper() + Fornavn.Substring(1).ToLower();
                Mellemnavn = Mellemnavn.First().ToString().ToUpper() + Mellemnavn.Substring(1).ToLower();
                Efternavn = Efternavn.First().ToString().ToUpper() + Efternavn.Substring(1).ToLower();
                if (Fornavn.Contains("-"))
                {
                    finddash = Fornavn.IndexOf("-");
                    Fornavn = Fornavn.Substring(0, finddash + 1) + Fornavn.Substring(finddash + 1, 1).ToUpper() + Fornavn.Substring(finddash + 2);
                }
                if (Mellemnavn.Contains("-"))
                {
                    finddash = Mellemnavn.IndexOf("-");
                    Mellemnavn = Mellemnavn.Substring(0, finddash + 1) + Mellemnavn.Substring(finddash + 1, 1).ToUpper() + Mellemnavn.Substring(finddash + 2);
                }
                if (Efternavn.Contains("-"))
                {
                    finddash = Efternavn.IndexOf("-");
                    Efternavn = Efternavn.Substring(0, finddash + 1) + Efternavn.Substring(finddash + 1, 1).ToUpper() + Efternavn.Substring(finddash + 2);
                }
                return Fornavn + Mellemnavn + Efternavn;
            }
            else
            {
                return "nothing";
            }
        }
        #endregion

        /// <summary>
        /// Metoder der udskriver værdier fra arrays
        /// </summary>
        #region Kapitel 4-2 Metoder
        static void ArrayDimensional()
        {
            int[] oneDim = new int[7] { 1, 242, 545, 23, 6, 535, 2448 };
            Console.WriteLine("Dette er det højeste tal i det ét-dimensionelle array: " + oneDim.Max());
            Console.WriteLine("Dette er det laveste tal i det ét-dimensionelle array: " + oneDim.Min());
            Console.WriteLine("Dette er summen af alle tal i det ét-dimensionelle array: " + oneDim.Sum());
            Console.WriteLine("Dette er antallet af værdier i det ét-dimensionelle array: " + oneDim.Count());
            Console.WriteLine("Dette er gennemsnittet af talene i det ét-dimensionelle array: " + oneDim.Average().ToString("00.00"));
            Console.WriteLine();
            string[,] twoDim = {
                { "[ ]", "[ ]", "[X]" },
                { "[ ]", "[ ]", "[X]" },
                { "[ ]", "[X]", "[ ]" },
                { "[X]", "[ ]", "[ ]" },
                { "[X]", "[ ]", "[ ]" },
                { "[ ]", "[ ]", "[X]" },
                { "[ ]", "[X]", "[ ]" },
                { "[ ]", "[X]", "[ ]" },
                { "[X]", "[ ]", "[ ]" },
                { "[X]", "[ ]", "[ ]" },
                { "[ ]", "[X]", "[ ]" },
                { "[X]", "[ ]", "[ ]" },
                { "[ ]", "[ ]", "[X]" }
            };
            for (int i = 0; i < twoDim.GetLength(0); i++)
            {
                if (i > 0)
                {
                    Console.WriteLine();
                }
                for (int j = 0; j < twoDim.GetLength(1); j++)
                {
                    Console.Write("{0}", twoDim[i, j]);
                }
            }
        }
        static void ArrayString()
        {
            Console.WriteLine("Udarbejdning af split string, overført til array og udskrevet på hver sin linje!");
            string something = "something this way comes quickly";
            string[] somethings = something.Split(' ');
            foreach (string c in somethings)
            {
                Console.WriteLine(c);
            }
            Console.ReadKey();
            Console.Clear();
        }
        #endregion
    }

}
