﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_2_CSharp
{
    class Bil
    {
        public static void BilMain() // Hovedprogrammet
        {
            Bil Objekt = new Bil(); // Laver et nyt objekt af Bil-klassen
            Objekt.MotorStart(); // Udskriver objektet "Objekt" med koden i metoden "MotorStart"
            Objekt.MotorStop(); // Udskriver objektet "Objekt" med koden i metoden "MotorStop"
            Console.Write("1. Diesel\n2. Gasoline\nChoose gastype: "); // Udskriver tekst
            string gasTypeMain = Console.ReadLine(); // Programmet spørger efter en indtastning og overfører værdien man indtaster til string variablen "gasTypeMain"
            bool gasBool; // Erklærer en bool variabel uden værdi
            if (gasTypeMain == "1") // Et if statement der kører koden herunder hvis dets parametrer er sande
            {
                gasBool = true; // Angiver bool "gasBool" som: True
            }
            else gasBool = false; // Et else statement der køres hvis if statement ikke er sandt - Angiver bool "gasBool" som: False

            Console.WriteLine(Bil.FillGas("2.5", gasBool)); // Udskriver et resultat af metoden FillGas

            double gasTilbage = Bil.RemainingGas(5); // Erklærer variablen "gasTilbage" og får sin værdi fra metoden "RemainingGas"
            Console.WriteLine(gasTilbage); // Udskriver værdien af variablen

            Console.WriteLine(Bil.RemainingGas(10)); // Udskriver værdien af metoden RemainingGas
            Console.ReadKey(); // Venter på et tastetryk før programmet går videre
        }
        public void MotorStart() // Laver en metode der returnerer alt kode
        {
            Console.WriteLine("Motoren er startet."); // Udskriver tekst
        }
        public void MotorStop() // Laver en metode der returnerer alt kode
        {
            Console.WriteLine("Motoren er slukket."); // Udskriver tekst
        }
        public static string FillGas(string litersstring, bool isDiesel) // Laver en metode der returnerer en string
        {
            string gasType; // Erklærer en variabel uden værdi
            if (isDiesel == true) // Et if statement der kører koden herunder hvis dets parametrer er sande
            {
                gasType = "diesel"; // Ændrer variablen "gasType" til "diesel"
            }
            else // Et else statement der køres hvis if statement ikke er sandt - Returnerer false til metoden
            {
                gasType = "gasoline"; // Ændrer variablen "gasType" til "gasoline"
            }
            double liters = double.Parse(litersstring); // Erklærer en variabel med værdien af variablen "litersstring"
            return "Filled tank with: " + liters + " liters of " + gasType; // Returnerer tekst + værdien af variablerne


        }
        public static double RemainingGas(double x) // Laver en metode der returnerer en double
        {
            return x; // Returnerer værdien af variablen x
        }
    }
}
