﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_2_CSharp
{
    class ProgramS
    {
        static void Main(string[] args)
        {
        start: // Et referencepunkt som programmet kan hoppe til
            Console.Title = "Opgave 2 - CSharp"; // Sætter titlen på konsollen til "Opgave 2 - CSharp"
            Console.Clear(); // Rydder konsolvinduet
            string opgaver; // Erklærer en string med navnet "opgaver" uden startværdi
            do // Starter et do-while loop
            {
                Console.Clear(); // Rydder konsolvinduet
                Console.WriteLine(" 1: Variabler " +
                    "\n 2: Strings " +
                    "\n 3: Aritmetiske udtryk " +
                    "\n 4: Variabler i udtryk " +
                    "\n 5: Boolske variable " +
                    "\n 6: If-else statements " +
                    "\n 7: Switch Case " +
                    "\n 8: Loops " +
                    "\n 9: Udvidet kontrolstrukturer " +
                    "\n 10: Bog Opgave " +
                    "\n 11: Bil Opgave " +
                    "\n 12: Furniture Opgave " +
                    "\n 13: Arrays " +
                    "\n 14: Konstruktors " +
                    "\n 15: Arrays " +
                    "\n\n 0: Afslut"); // Viser en liste over de forskellige slags opgaver og laver linjebrud med \n
                Console.Write("Vælg emne: "); // Skriver en tekst
                opgaver = Console.ReadLine(); // Programmet spørger efter en indtastning og overfører værdien man indtaster til string variablen "opgaver"

                switch (opgaver) //Laver en switch der arbejder ud fra variablen "opgaver"
                {
                    case "1": // Hvis variablen "opgaver" er = 1 går programmet hertil og kører koden herunder
                        string variabelOpgave; // Erklærer en string med navnet "variabelOpgave" uden startværdi
                        do // Starter et do-while loop
                        {

                            Console.Clear(); // Rydder konsolvinduet
                            Console.WriteLine("Variabler \nVælg opgave: 1-6\n   Indtast 0 for at gå tilbage"); // Udskriver tekst
                            Console.Write("Vælg opgave: "); // Udskriver tekst
                            variabelOpgave = Console.ReadLine(); // Programmet spørger efter en indtastning og overfører værdien man indtaster til string variablen "variabelOpgave"


                            switch (variabelOpgave) // Starter en switch-menu
                            {
                                case "1": // Hvis variablen "variabelOpgave" = 1 køres koden herunder.
                                    Variabel1(); // Kalder på en metode
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                                case "2": // Hvis variablen "variabelOpgave" = 2 køres koden herunder.
                                    Variabel2(); // Kalder på en metode
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                                case "3": // Hvis variablen "variabelOpgave" = 3 køres koden herunder.
                                    Variabel3(); // Kalder på en metode
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                                case "4": // Hvis variablen "variabelOpgave" = 4 køres koden herunder.
                                    Variabel4(); // Kalder på en metode
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                                case "5": // Hvis variablen "variabelOpgave" = 5 køres koden herunder.
                                    Variabel5(); // Kalder på en metode
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                                case "6": // Hvis variablen "variabelOpgave" = 6 køres koden herunder.
                                    Variabel6(); // Kalder på en metode
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                                default: // Hvis variablen "variabelOpgave" får en værdi der ikke findes i switch-menuen, køres koden herunder.
                                    if (variabelOpgave != "0") // Hvis variablen "variabelOpgave" ikke er = 0, køres koden herunder.
                                    {
                                        Console.Clear(); // Rydder konsolvinduet
                                        Console.WriteLine("Ugyldigt input, prøv igen."); // Udskriver tekst
                                        Console.ReadKey(); // Venter på et tastetryk før programmet går videre
                                    }
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                            }
                        } while (variabelOpgave != "0"); // Starter do-while loopet forfra hvis variabelOpgave ikke er = 0
                        goto start; // Når brugeren indtaster 0 som værdi til variablen "variabelOpgave" går programmet tilbage til start

                    case "2": // Hvis variablen "opgaver" er = 2 går programmet hertil og kører koden herunder
                        string stringOpgave; // Erklærer en string med navnet "stringOpgave" uden startværdi
                        do // // Starter et do-while loop
                        {
                            Console.Clear(); // Rydder konsolvinduet
                            Console.WriteLine("Strings \nVælg opgave: 1-4\n   Indtast 0 for at gå tilbage"); // Udskriver tekst
                            Console.Write("Vælg opgave: "); // Udskriver tekst
                            stringOpgave = Console.ReadLine(); // Programmet spørger efter en indtastning og overfører værdien man indtaster til string variablen "stringOpgave"

                            switch (stringOpgave) // Starter en switch-menu
                            {
                                case "1": // Hvis variablen "stringOpgave" = 1 køres koden herunder.
                                    String1();// Kalder på en metode
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                                case "2": // Hvis variablen "stringOpgave" = 2 køres koden herunder.
                                    String2();// Kalder på en metode
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                                case "3": // Hvis variablen "stringOpgave" = 3 køres koden herunder.
                                    String3();// Kalder på en metode
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                                case "4": // Hvis variablen "stringOpgave" = 4 køres koden herunder.
                                    String4();// Kalder på en metode
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                                default: // Hvis variablen "stringOpgave" får en værdi der ikke findes i switch-menuen, køres koden herunder.
                                    if (stringOpgave != "0") // Hvis variablen "stringOpgave" ikke er = 0, køres koden herunder.
                                    {
                                        Console.Clear(); // Rydder konsolvinduet
                                        Console.WriteLine("Ugyldigt input, prøv igen."); // Udskriver tekst
                                        Console.ReadKey(); // Venter på et tastetryk før programmet går videre
                                    }
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                            }
                        } while (stringOpgave != "0"); // Starter do-while loopet forfra hvis stringOpgave ikke er = 0
                        goto start; // Når brugeren indtaster 0 som værdi til variablen "stringOpgave" går programmet tilbage til start

                    case "3": // Hvis variablen "opgaver" er = 3 går programmet hertil og kører koden herunder
                        string aritmetikOpgave; // Erklærer en string med navnet "aritmetikOpgave" uden startværdi
                        do // Starter et do-while loop
                        {
                            Console.Clear(); // Rydder konsolvinduet
                            Console.WriteLine("Aritmetik \nTast 1 for at køre program\n   Indtast 0 for at gå tilbage"); // Udskriver tekst
                            Console.Write("Vælg opgave: "); // Udskriver tekst
                            aritmetikOpgave = Console.ReadLine(); // Programmet spørger efter en indtastning og overfører værdien man indtaster til string variablen "aritmetikOpgave"

                            switch (aritmetikOpgave) // Starter en switch-menu
                            {
                                case "1": // Hvis variablen "aritmetikOpgave" = 1 køres koden herunder.
                                    Aritmetik();// Kalder på en metode
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                                default: // Hvis variablen "aritmetikOpgave" får en værdi der ikke findes i switch-menuen, køres koden herunder.
                                    if (aritmetikOpgave != "0")// Hvis variablen "aritmetikOpgave" ikke er = 0, køres koden herunder.
                                    {
                                        Console.Clear(); // Rydder konsolvinduet
                                        Console.WriteLine("Ugyldigt input, prøv igen."); // Udskriver tekst
                                        Console.ReadKey(); // Venter på et tastetryk før programmet går videre
                                    }
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                            }
                        } while (aritmetikOpgave != "0"); // Starter do-while loopet forfra hvis aritmetikOpgave ikke er = 0
                        goto start; // Når brugeren indtaster 0 som værdi til variablen "aritmetikOpgave" går programmet tilbage til start

                    case "4": // Hvis variablen "opgaver" er = 4 går programmet hertil og kører koden herunder
                        string variablerudtrykOpgave; // Erklærer en string med navnet "variablerudtrykOpgave" uden startværdi
                        do // Starter et do-while loop
                        {
                            Console.Clear(); // Rydder konsolvinduet
                            Console.WriteLine("Variabler i udtryk \nVælg opgave: 1-2\n   Indtast 0 for at gå tilbage"); // Udskriver tekst
                            Console.Write("Vælg opgave: "); // Udskriver tekst
                            variablerudtrykOpgave = Console.ReadLine(); // Programmet spørger efter en indtastning og overfører værdien man indtaster til string variablen "variablerudtrykOpgave"

                            switch (variablerudtrykOpgave) // Starter en switch-menu
                            {
                                case "1": // Hvis variablen "variablerudtrykOpgave" = 1 køres koden herunder.
                                    Variabud1();// Kalder på en metode
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                                case "2": // Hvis variablen "variablerudtrykOpgave" = 2 køres koden herunder.
                                    Variabud2();// Kalder på en metode
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                                default: // Hvis variablen "variablerudtrykOpgave" får en værdi der ikke findes i switch-menuen, køres koden herunder.
                                    if (variablerudtrykOpgave != "0") // Hvis variablen "variablerudtrykOpgave" ikke er = 0, køres koden herunder.
                                    {
                                        Console.Clear(); // Rydder konsolvinduet
                                        Console.WriteLine("Ugyldigt input, prøv igen."); // Udskriver tekst
                                        Console.ReadKey(); // Venter på et tastetryk før programmet går videre
                                    }
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                            }
                        } while (variablerudtrykOpgave != "0"); // Starter do-while loopet forfra hvis aritmetikOpgave ikke er = 0
                        goto start; // Når brugeren indtaster 0 som værdi til variablen "variablerudtrykOpgave" går programmet tilbage til start

                    case "5": // Hvis variablen "opgaver" er = 5 går programmet hertil og kører koden herunder
                        string boolOpgave; // Erklærer en string med navnet "boolOpgave" uden startværdi
                        do // Starter et do-while loop
                        {
                            Console.Clear(); // Rydder konsolvinduet
                            Console.WriteLine("Boolske variable \nTast 1 for at køre program\n   Indtast 0 for at gå tilbage"); // Udskriver tekst
                            Console.Write("Vælg opgave: "); // Udskriver tekst
                            boolOpgave = Console.ReadLine(); // Programmet spørger efter en indtastning og overfører værdien man indtaster til string variablen "boolOpgave"

                            switch (boolOpgave) // Starter en switch-menu
                            {
                                case "1": // Hvis variablen "boolOpgave" = 1 køres koden herunder.
                                    Bool1();// Kalder på en metode
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                                default: // Hvis variablen "boolOpgave" får en værdi der ikke findes i switch-menuen, køres koden herunder.
                                    if (boolOpgave != "0") // Hvis variablen "boolOpgave" ikke er = 0, køres koden herunder.
                                    {
                                        Console.Clear(); // Rydder konsolvinduet
                                        Console.WriteLine("Ugyldigt input, prøv igen."); // Udskriver tekst
                                        Console.ReadKey(); // Venter på et tastetryk før programmet går videre
                                    }
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                            }
                        } while (boolOpgave != "0"); // Starter do-while loopet forfra hvis boolOpgave ikke er = 0
                        goto start; // Når brugeren indtaster 0 som værdi til variablen "boolOpgave" går programmet tilbage til start

                    case "6": // Hvis variablen "opgaver" er = 6 går programmet hertil og kører koden herunder
                        string ifelseOpgave; // Erklærer en string med navnet "ifelseOpgave" uden startværdi
                        do // Starter et do-while loop
                        {
                            Console.Clear(); // Rydder konsolvinduet
                            Console.WriteLine("If-else statements \nVælg opgave: 1-7\n   Indtast 0 for at gå tilbage"); // Udskriver tekst
                            Console.Write("Vælg opgave: "); // Udskriver tekst
                            ifelseOpgave = Console.ReadLine(); // Programmet spørger efter en indtastning og overfører værdien man indtaster til string variablen "boolOpgave"
                            switch (ifelseOpgave) // Starter en switch-menu
                            {
                                case "1": // Hvis variablen "ifelseOpgave" = 1 køres koden herunder.
                                    Ifelse1();// Kalder på en metode
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                                case "2": // Hvis variablen "ifelseOpgave" = 2 køres koden herunder.
                                    Ifelse2();// Kalder på en metode
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                                case "3": // Hvis variablen "ifelseOpgave" = 3 køres koden herunder.
                                    Ifelse3();// Kalder på en metode
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                                case "4": // Hvis variablen "ifelseOpgave" = 4 køres koden herunder.
                                    Ifelse4();// Kalder på en metode
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                                case "5": // Hvis variablen "ifelseOpgave" = 5 køres koden herunder.
                                    Ifelse5();// Kalder på en metode
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                                case "6": // Hvis variablen "ifelseOpgave" = 6 køres koden herunder.
                                    Ifelse6();// Kalder på en metode
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                                case "7": // Hvis variablen "ifelseOpgave" = 7 køres koden herunder.
                                    Ifelse7();// Kalder på en metode
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                                default: // Hvis variablen "ifelseOpgave" får en værdi der ikke findes i switch-menuen, køres koden herunder.
                                    if (ifelseOpgave != "0") // Hvis variablen "ifelseOpgave" ikke er = 0, køres koden herunder.
                                    {
                                        Console.Clear(); // Rydder konsolvinduet
                                        Console.WriteLine("Ugyldigt input, prøv igen."); // Udskriver tekst
                                        Console.ReadKey(); // Venter på et tastetryk før programmet går videre
                                    }
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                            }
                        } while (ifelseOpgave != "0"); // Starter do-while loopet forfra hvis ifelseOpgave ikke er = 0
                        goto start; // Når brugeren indtaster 0 som værdi til variablen "ifelseOpgave" går programmet tilbage til start

                    case "7": // Hvis variablen "opgaver" er = 7 går programmet hertil og kører koden herunder
                        string switchOpgave; // Erklærer en string med navnet "switchOpgave" uden startværdi
                        do // Starter et do-while loop
                        {
                            Console.Clear(); // Rydder konsolvinduet
                            Console.WriteLine("Switch Case \nVælg opgave: 1-2\n   Indtast 0 for at gå tilbage"); // Udskriver tekst
                            Console.Write("Vælg opgave: "); // Udskriver tekst
                            switchOpgave = Console.ReadLine(); // Programmet spørger efter en indtastning og overfører værdien man indtaster til string variablen "switchOpgave"
                            switch (switchOpgave) // Starter en switch-menu
                            {
                                case "1": // Hvis variablen "switchOpgave" = 1 køres koden herunder.
                                    Switch1();// Kalder på en metode
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                                case "2": // Hvis variablen "switchOpgave" = 2 køres koden herunder.
                                    Switch2();// Kalder på en metode
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                                default: // Hvis variablen "switchOpgave" får en værdi der ikke findes i switch-menuen, køres koden herunder.
                                    if (switchOpgave != "0") // Hvis variablen "switchOpgave" ikke er = 0, køres koden herunder.
                                    {
                                        Console.Clear(); // Rydder konsolvinduet
                                        Console.WriteLine("Ugyldigt input, prøv igen."); // Udskriver tekst
                                        Console.ReadKey(); // Venter på et tastetryk før programmet går videre
                                    }
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                            }
                        } while (switchOpgave != "0"); // Starter do-while loopet forfra hvis switchOpgave ikke er = 0
                        goto start; // Når brugeren indtaster 0 som værdi til variablen "switchOpgave" går programmet tilbage til start

                    case "8": // Hvis variablen "opgaver" er = 8 går programmet hertil og kører koden herunder
                        string loopsOpgave; // Erklærer en string med navnet "loopsOpgave" uden startværdi
                        do // Starter et do-while loop
                        {
                            Console.Clear(); // Rydder konsolvinduet
                            Console.WriteLine("Loops \nVælg opgave: 1-9\n   Indtast 0 for at gå tilbage"); // Udskriver tekst
                            Console.Write("Vælg opgave: "); // Udskriver tekst
                            loopsOpgave = Console.ReadLine(); // Programmet spørger efter en indtastning og overfører værdien man indtaster til string variablen "loopsOpgave"
                            switch (loopsOpgave) // Starter en switch-menu
                            {
                                case "1": // Hvis variablen "loopsOpgave" = 1 køres koden herunder.
                                    Loop1();// Kalder på en metode
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                                case "2": // Hvis variablen "loopsOpgave" = 2 køres koden herunder.
                                    Loop2();// Kalder på en metode
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                                case "3": // Hvis variablen "loopsOpgave" = 3 køres koden herunder.
                                    Loop3();// Kalder på en metode
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                                case "4": // Hvis variablen "loopsOpgave" = 4 køres koden herunder.
                                    Loop4();// Kalder på en metode
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                                case "5": // Hvis variablen "loopsOpgave" = 5 køres koden herunder.
                                    Loop5();// Kalder på en metode
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                                case "6": // Hvis variablen "loopsOpgave" = 6 køres koden herunder.
                                    Loop6();// Kalder på en metode
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                                case "7": // Hvis variablen "loopsOpgave" = 7 køres koden herunder.
                                    Loop7();// Kalder på en metode
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                                case "8": // Hvis variablen "loopsOpgave" = 8 køres koden herunder.
                                    Loop8();// Kalder på en metode
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                                case "9": // Hvis variablen "loopsOpgave" = 9 køres koden herunder.
                                    Loop9();// Kalder på en metode
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                                default: // Hvis variablen "loopsOpgave" får en værdi der ikke findes i switch-menuen, køres koden herunder.
                                    if (loopsOpgave != "0") // Hvis variablen "loopsOpgave" ikke er = 0, køres koden herunder.
                                    {
                                        Console.Clear(); // Rydder konsolvinduet
                                        Console.WriteLine("Ugyldigt input, prøv igen."); // Udskriver tekst
                                        Console.ReadKey(); // Venter på et tastetryk før programmet går videre
                                    }
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                            }
                        } while (loopsOpgave != "0"); // Starter do-while loopet forfra hvis loopsOpgave ikke er = 0
                        goto start; // Når brugeren indtaster 0 som værdi til variablen "loopsOpgave" går programmet tilbage til start

                    case "9": // Hvis variablen "opgaver" er = 9 går programmet hertil og kører koden herunder
                        string udkontrolOpgave; // Erklærer en string med navnet "udkontrolOpgave" uden startværdi
                        do // Starter et do-while loop
                        {
                            Console.Clear(); // Rydder konsolvinduet
                            Console.WriteLine("Udvidet kontrolstrukturer \nVælg opgave: 1-5\n   Indtast 0 for at gå tilbage"); // Udskriver tekst
                            Console.Write("Vælg opgave: "); // Udskriver tekst
                            udkontrolOpgave = Console.ReadLine(); // Programmet spørger efter en indtastning og overfører værdien man indtaster til string variablen "udkontrolOpgave"
                            switch (udkontrolOpgave) // Starter en switch-menu
                            {
                                case "1": // Hvis variablen "udkontrolOpgave" = 1 køres koden herunder.
                                    Udkons1();// Kalder på en metode
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                                case "2": // Hvis variablen "udkontrolOpgave" = 2 køres koden herunder.
                                    Udkons2();// Kalder på en metode
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                                case "3": // Hvis variablen "udkontrolOpgave" = 3 køres koden herunder.
                                    Udkons3();// Kalder på en metode
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                                case "4": // Hvis variablen "udkontrolOpgave" = 4 køres koden herunder.
                                    Udkons4();// Kalder på en metode
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                                case "5": // Hvis variablen "udkontrolOpgave" = 5 køres koden herunder.
                                    Udkons5();// Kalder på en metode
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                                default: // Hvis variablen "udkontrolOpgave" får en værdi der ikke findes i switch-menuen, køres koden herunder.
                                    if (udkontrolOpgave != "0") // Hvis variablen "udkontrolOpgave" ikke er = 0, køres koden herunder.
                                    {
                                        Console.Clear(); // Rydder konsolvinduet
                                        Console.WriteLine("Ugyldigt input, prøv igen."); // Udskriver tekst
                                        Console.ReadKey(); // Venter på et tastetryk før programmet går videre
                                    }
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                            }
                        } while (udkontrolOpgave != "0"); // Starter do-while loopet forfra hvis udkontrolOpgave ikke er = 0
                        goto start; // Når brugeren indtaster 0 som værdi til variablen "udkontrolOpgave" går programmet tilbage til start

                    case "10": // Hvis variablen "opgaver" er = 10 går programmet hertil og kører koden herunder
                        string BogOpgave; // Erklærer en string med navnet "BogOpgave" uden startværdi
                        do // Starter et do-while loop
                        {
                            Console.Clear(); // Rydder konsolvinduet
                            Console.WriteLine("Bog opgave \nTast 1 for at køre program\n   Indtast 0 for at gå tilbage"); // Udskriver tekst
                            Console.Write("Vælg opgave: "); // Udskriver tekst
                            BogOpgave = Console.ReadLine(); // Programmet spørger efter en indtastning og overfører værdien man indtaster til string variablen "BogOpgave"
                            switch (BogOpgave) // Starter en switch-menu
                            {
                                case "1": // Hvis variablen "BogOpgave" = 1 køres koden herunder.
                                    Bog.MainBog();// Kalder på en metode
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                                default: // Hvis variablen "BogOpgave" får en værdi der ikke findes i switch-menuen, køres koden herunder.
                                    if (BogOpgave != "0") // Hvis variablen "BogOpgave" ikke er = 0, køres koden herunder.
                                    {
                                        Console.Clear(); // Rydder konsolvinduet
                                        Console.WriteLine("Ugyldigt input, prøv igen."); // Udskriver tekst
                                        Console.ReadKey(); // Venter på et tastetryk før programmet går videre
                                    }
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                            }
                        } while (BogOpgave != "0"); // Starter do-while loopet forfra hvis BogOpgave ikke er = 0
                        goto start; // Når brugeren indtaster 0 som værdi til variablen "BogOpgave" går programmet tilbage til start

                    case "11": // Hvis variablen "opgaver" er = 11 går programmet hertil og kører koden herunder
                        string BilOpgave; // Erklærer en string med navnet "BilOpgave" uden startværdi
                        do // Starter et do-while loop
                        {
                            Console.Clear(); // Rydder konsolvinduet
                            Console.WriteLine("Bil Opgave \nTast 1 for at køre program\n   Indtast 0 for at gå tilbage"); // Udskriver tekst
                            Console.Write("Vælg opgave: "); // Udskriver tekst
                            BilOpgave = Console.ReadLine(); // Programmet spørger efter en indtastning og overfører værdien man indtaster til string variablen "BilOpgave"
                            switch (BilOpgave) // Starter en switch-menu
                            {
                                case "1": // Hvis variablen "BilOpgave" = 1 køres koden herunder.
                                    Bil.BilMain();// Kalder på en metode
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                                default: // Hvis variablen "BilOpgave" får en værdi der ikke findes i switch-menuen, køres koden herunder.
                                    if (BilOpgave != "0") // Hvis variablen "BilOpgave" ikke er = 0, køres koden herunder.
                                    {
                                        Console.Clear(); // Rydder konsolvinduet
                                        Console.WriteLine("Ugyldigt input, prøv igen."); // Udskriver tekst
                                        Console.ReadKey(); // Venter på et tastetryk før programmet går videre
                                    }
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                            }
                        } while (BilOpgave != "0"); // Starter do-while loopet forfra hvis BilOpgave ikke er = 0
                        goto start; // Når brugeren indtaster 0 som værdi til variablen "BilOpgave" går programmet tilbage til start

                    case "12": // Hvis variablen "opgaver" er = 12 går programmet hertil og kører koden herunder
                        string FurnitureOpgave; // Erklærer en string med navnet "FurnitureOpgave" uden startværdi
                        do // Starter et do-while loop
                        {
                            Console.Clear(); // Rydder konsolvinduet
                            Console.WriteLine("Furniture Opgave \nTast 1 for at køre program\n   Indtast 0 for at gå tilbage"); // Udskriver tekst
                            Console.Write("Vælg opgave: "); // Udskriver tekst
                            FurnitureOpgave = Console.ReadLine(); // Programmet spørger efter en indtastning og overfører værdien man indtaster til string variablen "FurnitureOpgave"
                            switch (FurnitureOpgave) // Starter en switch-menu
                            {
                                case "1": // Hvis variablen "FurnitureOpgave" = 1 køres koden herunder.
                                    Furniture.FurnitureMain();// Kalder på en metode
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                                default: // Hvis variablen "FurnitureOpgave" får en værdi der ikke findes i switch-menuen, køres koden herunder.
                                    if (FurnitureOpgave != "0") // Hvis variablen "FurnitureOpgave" ikke er = 0, køres koden herunder.
                                    {
                                        Console.Clear(); // Rydder konsolvinduet
                                        Console.WriteLine("Ugyldigt input, prøv igen."); // Udskriver tekst
                                        Console.ReadKey(); // Venter på et tastetryk før programmet går videre
                                    }
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                            }
                        } while (FurnitureOpgave != "0"); // Starter do-while loopet forfra hvis FurnitureOpgave ikke er = 0
                        goto start; // Når brugeren indtaster 0 som værdi til variablen "FurnitureOpgave" går programmet tilbage til start

                    case "13": // Hvis variablen "opgaver" er = 13 går programmet hertil og kører koden herunder
                        string arrayOpgave; // Erklærer en string med navnet "arrayOpgave" uden startværdi
                        do // Starter et do-while loop
                        {
                            Console.Clear(); // Rydder konsolvinduet
                            Console.WriteLine("Arrays \nVælg opgave: 1-2\n   Indtast 0 for at gå tilbage"); // Udskriver tekst
                            Console.Write("Vælg opgave: "); // Udskriver tekst
                            arrayOpgave = Console.ReadLine(); // Programmet spørger efter en indtastning og overfører værdien man indtaster til string variablen "arrayOpgave"
                            switch (arrayOpgave)
                            {
                                case "1": // Hvis variablen "FurnitureOpgave" = 1 køres koden herunder.
                                    Array1();// Kalder på en metode
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                                case "2":
                                    Array2();// Kalder på en metode
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                                default:
                                    if (arrayOpgave != "0")
                                    {
                                        Console.Clear(); // Rydder konsolvinduet
                                        Console.WriteLine("Ugyldigt input, prøv igen."); // Udskriver tekst
                                        Console.ReadKey(); // Venter på et tastetryk før programmet går videre
                                    }
                                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                            }
                        } while (arrayOpgave != "0"); // Starter do-while loopet forfra hvis arrayOpgave ikke er = 0
                        goto start; // Når brugeren indtaster 0 som værdi til variablen "arrayOpgave" går programmet tilbage til start

                    default: // Hvis den værdi der bliver angivet til variablen der styrer vores switch, vil programmet køre default
                        if (opgaver != "0") // Et if statement der kører koden herunder hvis dets parametrer er sande
                        {
                            Console.Clear(); // Rydder konsolvinduet
                            Console.WriteLine("Ugyldigt input, prøv igen."); // Udskriver tekst
                            Console.ReadKey(); // Venter på et tastetryk før programmet går videre
                        }
                        break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                }
            } while (opgaver != "0"); // Sender brugeren tilbage til starten af do-while loopet hvis variablen "opgaver" ikke er = 0
            Console.WriteLine(); // Udskriver tekst
            Console.ForegroundColor = ConsoleColor.Red; // Ændrer tekstfarven til rød
            Console.Write("Du har valgt at afslutte. Ha' en go' dag!"); // Udskriver tekst
            Console.ForegroundColor = ConsoleColor.White; // Ændrer tekstfarven til hvid
            Console.ReadKey(); // Venter på et tastetryk før programmet går videre
        } // Hovedprogrammet
        static void Variabel1() // Laver en metode der returnerer alt kode
        {
            int tal1 = 5, tal2 = 3; // Erklærer to variabler med værdien 5 og 3
            Console.Clear(); // Rydder konsolvinduet
            Console.WriteLine(tal1); // Udskriver værdien af variablen "tal1"
            Console.WriteLine(tal2); // Udskriver værdien af variablen "tal2"
            Console.ReadKey(); // Venter på et tastetryk før programmet går videre
        }
        static void Variabel2()// Laver en metode der returnerer alt kode
        {
            int tal1 = 5, tal2 = 3; // Erklærer to variabler med værdierne 5 og 3
            Console.Clear(); // Rydder konsolvinduet
            Console.WriteLine("Tal1 er {0}", tal1); // Udskriver en tekst efterfulgt af værdien af den indekserede variabel.
            Console.WriteLine("Tal2 er {0}", tal2); // Udskriver en tekst efterfulgt af værdien af den indekserede variabel.
            Console.ReadKey(); // Venter på et tastetryk før programmet går videre
        }
        static void Variabel3() // Laver en metode der returnerer alt kode
        {
            Console.Clear(); // Rydder konsolvinduet
            string navn = "Søren"; // Erklærer en variabel med værdien "Søren"
            int alder = 16; // Erklærer en variabel med værdien 16
            double penge = 1234.34; // Erklærer en variabel med værdien 1234,34
            Console.Write("Jeg hedder {0}, er {1} år gammel og har tjent {2} kr. på at lappe cykler.", navn, alder, penge); // Udskriver en tekst efterfulgt af værdierne af de indekserede variabler. 
            Console.ReadKey(); // Venter på et tastetryk før programmet går videre
        }
        static void Variabel4() // Laver en metode der returnerer alt kode
        {
            Console.Clear(); // Rydder konsolvinduet
            double kage = 23.56, øl = 34.67, pølse = 65.34; // Erklærer tre variabler med værdierne 23,56 - 34,67 & 65,34
            Console.WriteLine("Kage\t{0} \nØl\t{1}\nPølse\t{2}\nI alt\t{3}", kage, øl, pølse, kage + øl + pølse); // Udskriver en tekst efterfulgt af værdierne af de indekserede variabler.
            Console.ReadKey(); // Venter på et tastetryk før programmet går videre
        }
        static void Variabel5() // Laver en metode der returnerer alt kode
        {
            Console.Clear(); // Rydder konsolvinduet
            Console.Write("Indtast navn: "); // Udskriver tekst
            string navn_5 = Console.ReadLine(); // Programmet spørger efter en indtastning og overfører værdien man indtaster til string variablen "navn_5"
            Console.Write("Indtast alder: "); // Udskriver tekst
            int alder_5 = int.Parse(Console.ReadLine()); // Programmet spørger efter en indtastning og overfører værdien man indtaster til string variablen "alder_5"
            Console.Write("Jeg hedder {0} og er {1} år gammel.", navn_5, alder_5); // Udskriver en tekst efterfulgt af værdierne af de indekserede variabler.
            Console.ReadKey(); // Venter på et tastetryk før programmet går videre
        }
        static void Variabel6() // Laver en metode der returnerer alt kode
        {
            Console.Clear(); // Rydder konsolvinduet
            Console.Write("Udregning af areal af en cirkel.\nIndtast radius i centimeter: "); // Udskriver tekst
            double radius_6 = double.Parse(Console.ReadLine()); // Programmet spørger efter en indtastning og overfører værdien man indtaster til double variablen "radius_6"
            Console.Write("Arealet af cirklen er: {0:0.00} kvadratcentimeter", Math.Pow(radius_6, 2) * Math.PI); // Udskriver en tekst efterfulgt af værdierne af de indekserede variabler.
            Console.ReadKey(); // Venter på et tastetryk før programmet går videre
        }
        static void String1() // Laver en metode der returnerer alt kode
        {
            int integer = 1; // Erklærer en variabel med værdien 1
            string stringent = "Hej"; // Erklærer en variabel med værdien "Hej"
            double doublent = 3.21; // Erklærer en variabel med værdien 3,21
            Console.Clear(); // Rydder konsolvinduet
            Console.Write("{0}\n{1}\n{2}", integer, stringent, doublent); // Udskriver en tekst efterfulgt af værdierne af de indekserede variabler.
            Console.ReadKey(); // Venter på et tastetryk før programmet går videre
        }
        static void String2() // Laver en metode der returnerer alt kode
        {
            int integer = 1; // Erklærer en variabel med værdien 10
            string stringent = "Hej"; // Erklærer en variabel med værdien "Hej"
            double doublent = 3.21; // Erklærer en variabel med værdien 3,21
            Console.Clear(); // Rydder konsolvinduet 
            integer = 10;
            Console.Write("{0}\n{1}\n{2}", integer, stringent, doublent); // Udskriver en tekst efterfulgt af værdierne af de indekserede variabler.
            Console.ReadKey(); // Venter på et tastetryk før programmet går videre
        }
        static void String3() // Laver en metode der returnerer alt kode
        {
            Console.Clear(); // Rydder konsolvinduet
            string tekst = "I dag har vi den 24. December."; // Erklærer en variabel med værdien "I dag har vi den 24. December."
            Console.Write(tekst); // Udskriver værdien af variablen "tekst"
            Console.ReadKey(); // Venter på et tastetryk før programmet går videre
        }
        static void String4() // Laver en metode der returnerer alt kode
        {
            Console.Clear(); // Rydder konsolvinduet
            double tal = 200.50; // Erklærer en variabel med værdien "200,50"
            string tekst = "Jeg har ", tekst2 = "kr. i banken"; // Erklærer to variabler med værdierne "Jeg har " & "kr. i banken"
            Console.Write(tekst + "{0:0.00}" + tekst2, tal); // Udskriver en tekst efterfulgt af værdierne af de indekserede variabler.
            Console.ReadKey(); // Venter på et tastetryk før programmet går videre
        }
        static void Aritmetik() // Laver en metode der returnerer alt kode
        {
            Console.Clear(); // Rydder konsolvinduet
            double arit1 = 2 + 1 * 2; // Erklærer en variabel med værdien "2 + 1 * 2"
            Console.WriteLine("2+1*2 = " + arit1); // Udskriver en tekst efterfulgt af værdierne af variablens værdi.
            double arit2 = (2 + 1) * 2; // Erklærer en variabel med værdien "(2 + 1) * 2"
            Console.WriteLine("(2 + 1) * 2 = " + arit2); // Udskriver en tekst efterfulgt af værdierne af variablens værdi.
            double arit3 = 5 / 2; // Erklærer en variabel med værdien "5 / 2"
            Console.WriteLine("5 / 2 = " + arit3); // Udskriver en tekst efterfulgt af værdierne af variablens værdi.
            double arit4 = 8 % 3; // Erklærer en variabel med værdien "8 % 3" (% er modulus, så programmet vil dividere 8 med 3 og finde restværdien. Altså er variablen arit4 = 2)
            Console.WriteLine("8 % 3 = " + arit4); // Udskriver en tekst efterfulgt af værdierne af variablens værdi.
            double arit5 = 1 - 5; // Erklærer en variabel med værdien "1 - 5"
            Console.WriteLine("1 - 5 = " + arit5); // Udskriver en tekst efterfulgt af værdierne af variablens værdi.
            Console.ReadKey(); // Venter på et tastetryk før programmet går videre
        }
        static void Variabud1() // Laver en metode der returnerer alt kode
        {
            Console.Clear(); // Rydder konsolvinduet
            double varia1 = 156, varia2 = 1991, varia3 = 28, result; // Erklærer 4 variabler med værdierne 156, 1991, 28 og ingen værdi

            result = varia1 * varia3 / varia2; // Regner en værdi ud af de tre variabler og overfører værdien til variablen "result"

            Console.Write(varia1 + " * " + varia3 + " / " + varia2 + " = {0:0.00}", result); // Udskriver en tekst efterfulgt af værdierne af de indekserede variabler.
            Console.ReadKey(); // Venter på et tastetryk før programmet går videre
        }
        static void Variabud2() // Laver en metode der returnerer alt kode
        {
            Console.Clear(); // Rydder konsolvinduet
            double varia1 = 561, varia2 = 2222, varia3 = 0, result; // Erklærer 4 variabler med værdierne 561, 2222, 0 og ingen værdi

            result = varia1 + 10 + varia2 / 50 - varia3 * 200; // Regner en værdi ud af de tre variabler + tilfældige tal og overfører værdien til variablen "result"

            Console.Write(varia1 + " + 10 + " + varia2 + " / 50 - " + varia3 + " * 200 = {0:0.00}", result); // Udskriver en tekst efterfulgt af værdierne af de indekserede variabler.
            Console.ReadKey(); // Venter på et tastetryk før programmet går videre
        }
        static void Bool1() // Laver en metode der returnerer alt kode
        {
            Console.Clear(); // Rydder konsolvinduet
            int var1 = 10, var2 = 100; // Erklærer 2 variabler med værdierne 10 og 100
            bool boole = var1 > var2; // Erklærer en variabel der tjekker om et statement er true/false
            Console.Clear(); // Rydder konsolvinduet
            Console.WriteLine("Variabler \nvar1 = 10 \nvar2 = 100 \nboole = var1 > var2"); // Udskriver en tekst
            Console.ReadKey(); // Venter på et tastetryk før programmet går videre
            Console.WriteLine("Er var1 højere end var2?: " + boole); // Udskriver en tekst efterfulgt af værdien af variablen boole
            Console.ReadKey(); // Venter på et tastetryk før programmet går videre
            Console.WriteLine("Ændrer værdien af variablen var1, så var1 har en højere værdi end var2. \nvar1 = 101 \nvar2 = 100"); // Udskriver en tekst
            Console.ReadKey(); // Venter på et tastetryk før programmet går videre
            var1 = 101; // Ændrer værdien af variablen var1
            boole = var1 > var2; // Variablen tjekker igen om vores statement er true/false
            Console.Write("Er var1 højere end var2?: " + boole); // Udskriver en tekst efterfulgt af værdien af variablen boole
            Console.ReadKey(); // Venter på et tastetryk før programmet går videre
        }
        static void Ifelse1() // Laver en metode der returnerer alt kode
        {
            Console.Clear(); // Rydder konsolvinduet
            int tal1 = 42, tal2 = 64, result = tal1 + tal2; // Erklærer 3 variabler med værdierne 42 og 64

            Console.WriteLine(tal1 + " + " + tal2 + " = " + result); // Udskriver en tekst + værdien af variabler
            if (result >= 100) // Et if statement der kører koden herunder hvis dets parametrer er sande
            {
                Console.Write("Summen er større end 100!"); // Udskriver en tekst
            }
            else if (result == 100) // Et else if statement der kører koden herunder hvis dets parametrer er sande, så længe det første statement ikke var sandt
            {
                Console.Write("Summen er 100"); // Udskriver en tekst
            }
            else // Et else statement der kører koden herunder hvis ingen if/else-if statements er sande
            {
                Console.Write("Summen er mindre end 100."); // Udskriver en tekst
            }
            Console.ReadKey(); // Venter på et tastetryk før programmet går videre
        }
        static void Ifelse2() // Laver en metode der returnerer alt kode
        {
            Console.Clear(); // Rydder konsolvinduet
            Console.Write("Indtast venligst din alder: "); // Udskriver en tekst
            int alder = int.Parse(Console.ReadLine()); // Programmet spørger efter en indtastning og overfører værdien man indtaster til string variablen "alder"

            if (alder > 57) // Et if statement der kører koden herunder hvis dets parametrer er sande
            {
                Console.Write("Du er for gammel!"); // Udskriver en tekst
            }
            else // Et else statement der kører koden herunder hvis ingen if/else-if statements er sande
            {
                Console.Write("Du er ikke for gammel!"); // Udskriver en tekst
            }
            Console.ReadKey(); // Venter på et tastetryk før programmet går videre
        }
        static void Ifelse3() // Laver en metode der returnerer alt kode
        {
            Console.Clear(); // Rydder konsolvinduet
            Console.Write("Indtast venligst din alder: "); // Udskriver en tekst
            int alder = int.Parse(Console.ReadLine()); // Programmet spørger efter en indtastning og overfører værdien man indtaster til string variablen "alder"

            if (alder > 60) // Et if statement der kører koden herunder hvis dets parametrer er sande
            {
                Console.Write("Du er for gammel!"); // Udskriver en tekst
            }
            else if (alder >= 50 && alder <= 60) // Et else if statement der kører koden herunder hvis dets parametrer er sande, så længe det første statement ikke var sandt
            {
                Console.Write("Du er hverken for gammel eller for ung!"); // Udskriver en tekst
            }
            else // Et else statement der kører koden herunder hvis ingen if/else-if statements er sande
            {
                Console.Write("Du er for ung!"); // Udskriver en tekst
            }
            Console.ReadKey(); // Venter på et tastetryk før programmet går videre
        }
        static void Ifelse4() // Laver en metode der returnerer alt kode
        {
            string brugerserver = "nicsam", kodeserver = "Passw0rd"; // Erklærer 2 variabler med værdierne "nicsam" og "Passw0rd"

            Console.Clear(); // Rydder konsolvinduet
            Console.Write("Indtast dit navn: "); // Udskriver en tekst
            string navn = Console.ReadLine(); // Programmet spørger efter en indtastning og overfører værdien man indtaster til string variablen "navn"
            Console.Write("Indtast brugernavn: "); // Udskriver en tekst
            string brugernavn = Console.ReadLine(); // Programmet spørger efter en indtastning og overfører værdien man indtaster til string variablen "brugernavn"
            Console.Write("Indtast kodeord: "); // Udskriver en tekst
            string kode = Console.ReadLine(); // Programmet spørger efter en indtastning og overfører værdien man indtaster til string variablen "kode"

            if (brugernavn == brugerserver && kode == kodeserver) // Et if statement der kører koden herunder hvis dets parametrer er sande
            {
                Console.Clear(); // Rydder konsolvinduet
                Console.Write("Velkommen {0}!", navn); // Udskriver en tekst efterfulgt af værdierne af de indekserede variabler.
            }
            else // Et else statement der kører koden herunder hvis ingen if/else-if statements er sande
            {
                Console.Clear(); // Rydder konsolvinduet
                Console.Write("Brugernavn eller password er forkert."); // Udskriver en tekst
            }
            Console.ReadKey(); // Venter på et tastetryk før programmet går videre
        }
        static void Ifelse5() // Laver en metode der returnerer alt kode
        {
            string brugerserver = "nicsam", kodeserver = "Passw0rd"; // Erklærer 2 variabler med værdierne "nicsam" og "Passw0rd"

            Console.Clear(); // Rydder konsolvinduet
            Console.Write("Indtast dit navn: "); // Udskriver en tekst
            string navn = Console.ReadLine(); // Programmet spørger efter en indtastning og overfører værdien man indtaster til string variablen "navn"
            Console.Write("Indtast brugernavn: "); // Udskriver en tekst
            string brugernavn = Console.ReadLine(); // Programmet spørger efter en indtastning og overfører værdien man indtaster til string variablen "brugernavn"
            if (brugernavn == brugerserver) // Et if statement der kører koden herunder hvis dets parametrer er sande
            {
                Console.Write("Indtast kodeord: "); // Udskriver en tekst
                string kode = Console.ReadLine(); // Programmet spørger efter en indtastning og overfører værdien man indtaster til string variablen "kode"
                if (kode == kodeserver) // Et if statement der kører koden herunder hvis dets parametrer er sande
                {
                    Console.Clear(); // Rydder konsolvinduet
                    Console.Write("Velkommen {0}!", navn); // Udskriver en tekst efterfulgt af værdierne af de indekserede variabler.
                }
                else // Et else statement der kører koden herunder hvis ingen if/else-if statements er sande
                {
                    Console.Clear(); // Rydder konsolvinduet
                    Console.Write("Kodeord er forkert!"); // Udskriver en tekst
                }
            }
            else // Et else statement der kører koden herunder hvis ingen if/else-if statements er sande
            {
                Console.Clear(); // Rydder konsolvinduet
                Console.Write("Brugernavn er forkert."); // Udskriver en tekst
            }
            Console.ReadKey(); // Venter på et tastetryk før programmet går videre
        }
        static void Ifelse6() // Laver en metode der returnerer alt kode
        {
            Console.Clear(); // Rydder konsolvinduet
            Console.WriteLine("Indtast distance kørt hver dag til og fra arbejde i km: "); // Udskriver en tekst
            double distance = double.Parse(Console.ReadLine()); // Programmet spørger efter en indtastning og overfører værdien man indtaster til string variablen "distance"
            if (distance > 0 && distance <= 24) // Et if statement der kører koden herunder hvis dets parametrer er sande
            {
                Console.WriteLine("Du får ikke noget fradrag."); // Udskriver en tekst
            }
            else if (distance > 24 && distance <= 120) // Et else if statement der kører koden herunder hvis dets parametrer er sande, så længe det første statement ikke var sandt
            {
                double fradrag1 = (distance - 24) * 1.93; // Erklærer en variabel med værdien "(distance - 24) * 1,93"
                Console.Write("Da du har {0} km til og fra arbejde får du {1} kr i fradrag!", distance, fradrag1); // Udskriver en tekst efterfulgt af værdierne af de indekserede variabler.
            }
            else if (distance > 120) // Et else if statement der kører koden herunder hvis dets parametrer er sande, så længe det første statement ikke var sandt
            {
                double fradrag2 = 96 * 1.93 + (distance - 120) * 0.97; // Erklærer en variabel med værdien "(distance - 120) * 0,97"
                Console.Write("Da du har {0} km til og fra arbejde får du {1} kr i fradrag!", distance, fradrag2); // Udskriver en tekst efterfulgt af værdierne af de indekserede variabler.
            }
            else // Et else statement der kører koden herunder hvis ingen if/else-if statements er sande
            {
                Console.Clear(); // Rydder konsolvinduet
                Console.Write("Din indtastning skal være over 0"); // Udskriver en tekst
            }
            Console.ReadKey(); // Venter på et tastetryk før programmet går videre
        }
        static void Ifelse7() // Laver en metode der returnerer alt kode
        {
            string farve; // Erklærer en variabel uden værdi
            int alder; // Erklærer en variabel uden værdi
            do // Starter et do-while loop
            {
                Console.Clear(); // Rydder konsolvinduet
                Console.Title = "Festen"; // Sætter titlen på konsolvinduet til "Festen"
                Console.Write("Hvilken farve foretrækker du?\nRød, grøn, blå eller gul?: "); // Udskriver en tekst
                farve = Console.ReadLine().ToLower(); // Programmet spørger efter en indtastning, overfører værdien man indtaster til string variablen "farve" og gemmer teksten med små bogstaver
                Console.Write("Indtast din alder(max 100): "); // Udskriver en tekst
                alder = int.Parse(Console.ReadLine()); // Programmet spørger efter en indtastning og overfører værdien man indtaster til string variablen "alder"

                if (farve == "rod" && alder > 0 && alder <= 100) // Et if statement der kører koden herunder hvis dets parametrer er sande
                {
                    Console.BackgroundColor = ConsoleColor.Red; // Sætter baggrundsfarven til rød
                    Console.Clear(); // Rydder konsolvinduet
                    if (alder >= 18) // Et if statement der kører koden herunder hvis dets parametrer er sande
                    {
                        Console.Write("Velkommen til cocktailbaren!"); // Udskriver en tekst
                        System.Threading.Thread.Sleep(10000); // Sætter programmet til at pause alle handlinger i 10 sekunder
                    }
                    else if (alder >= 0) // Et else if statement der kører koden herunder hvis dets parametrer er sande, så længe det første statement ikke var sandt
                    {
                        Console.Write("Velkommen til sodavandsbaren!"); // Udskriver en tekst
                        System.Threading.Thread.Sleep(10000); // Sætter programmet til at pause alle handlinger i 10 sekunder
                    }
                }
                else if (farve == "gron" && alder > 0 && alder <= 100) // Et else if statement der kører koden herunder hvis dets parametrer er sande, så længe det første statement ikke var sandt
                {
                    Console.BackgroundColor = ConsoleColor.Green; // Sætter baggrundsfarven til grøn
                    Console.Clear(); // Rydder konsolvinduet
                    if (alder >= 18) // Et if statement der kører koden herunder hvis dets parametrer er sande
                    {
                        Console.Write("Velkommen til cocktailbaren!"); // Udskriver en tekst
                        System.Threading.Thread.Sleep(10000); // Sætter programmet til at pause alle handlinger i 10 sekunder
                    }
                    else if (alder >= 0 && alder < 18) // Et else if statement der kører koden herunder hvis dets parametrer er sande, så længe det første statement ikke var sandt
                    {
                        Console.Write("Velkommen til sodavandsbaren!"); // Udskriver en tekst
                        System.Threading.Thread.Sleep(10000); // Sætter programmet til at pause alle handlinger i 10 sekunder
                    }
                }
                else if (farve == "blå" && alder > 0 && alder <= 100) // Et else if statement der kører koden herunder hvis dets parametrer er sande, så længe det første statement ikke var sandt
                {
                    Console.BackgroundColor = ConsoleColor.Blue; // Sætter baggrundsfarven til blå
                    Console.Clear(); // Rydder konsolvinduet
                    if (alder >= 18) // Et if statement der kører koden herunder hvis dets parametrer er sande
                    {
                        Console.Write("Velkommen til cocktailbaren!"); // Udskriver en tekst
                        System.Threading.Thread.Sleep(10000); // Sætter programmet til at pause alle handlinger i 10 sekunder
                    }
                    else if (alder >= 0 && alder < 18) // Et else if statement der kører koden herunder hvis dets parametrer er sande, så længe det første statement ikke var sandt
                    {
                        Console.Write("Velkommen til sodavandsbaren!"); // Udskriver en tekst
                        System.Threading.Thread.Sleep(10000); // Sætter programmet til at pause alle handlinger i 10 sekunder
                    }
                }
                else if (farve == "gul" && alder > 0 && alder <= 100) // Et else if statement der kører koden herunder hvis dets parametrer er sande, så længe det første statement ikke var sandt
                {
                    Console.BackgroundColor = ConsoleColor.Yellow; // Sætter baggrundsfarven til gul
                    Console.Clear(); // Rydder konsolvinduet
                    if (alder >= 18) // Et if statement der kører koden herunder hvis dets parametrer er sande
                    {
                        Console.Write("Velkommen til cocktailbaren!"); // Udskriver en tekst
                        System.Threading.Thread.Sleep(10000); // Sætter programmet til at pause alle handlinger i 10 sekunder
                    }
                    else if (alder >= 0 && alder < 18) // Et else if statement der kører koden herunder hvis dets parametrer er sande, så længe det første statement ikke var sandt
                    {
                        Console.Write("Velkommen til sodavandsbaren!"); // Udskriver en tekst
                        System.Threading.Thread.Sleep(10000); // Sætter programmet til at pause alle handlinger i 10 sekunder
                    }
                }
                else // Et else statement der kører koden herunder hvis ingen if/else-if statements er sande
                {
                    Console.Clear(); // Rydder konsolvinduet
                    Console.Write("Ugyldig alder eller farve, prøv igen."); // Udskriver en tekst
                    Console.ReadKey(); // Venter på et tastetryk før programmet går videre
                }
            } while (farve != "rod" && farve != "gron" && farve != "blå" && farve != "gul" && alder < 0 && alder > 100); // Sender brugeren tilbage til starten af do-while loopet hvis variablen ikk er lig med nogen af parametrene
            Console.BackgroundColor = ConsoleColor.Black; // Sætter baggrundsfarven til sort
            Console.Title = "Opgave 2 - CSharp";  // Sætter titlen på konsolvinduet til "Opgave 2 - CSharp"
        }
        static void Switch1() // Laver en metode der returnerer alt kode
        {
            string valg; // Erklærer en variabel uden værdi

            Console.Clear(); // Rydder konsolvinduet
            Console.Write("Indtast et tal mellem 1 & 6: "); // Udskriver en tekst
            valg = Console.ReadLine(); // Programmet spørger efter en indtastning og overfører værdien man indtaster til string variablen "valg"
            switch (valg) //Laver en switch der arbejder ud fra variablen "valg"
            {
                case "1": // Hvis variablen "valg" er = 1 går programmet hertil og kører koden herunder
                    Console.Clear(); // Rydder konsolvinduet
                    Console.Write("Du har tastet: " + valg); // Udskriver en tekst + værdien på variablen
                    Console.ReadKey(); // Venter på et tastetryk før programmet går videre
                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                case "2": // Hvis variablen "valg" er = 2 går programmet hertil og kører koden herunder
                    Console.Clear(); // Rydder konsolvinduet
                    Console.Write("Du har tastet: " + valg); // Udskriver en tekst + værdien på variablen
                    Console.ReadKey(); // Venter på et tastetryk før programmet går videre
                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                case "3": // Hvis variablen "valg" er = 3 går programmet hertil og kører koden herunder
                    Console.Clear(); // Rydder konsolvinduet
                    Console.Write("Du har tastet: " + valg); // Udskriver en tekst + værdien på variablen
                    Console.ReadKey(); // Venter på et tastetryk før programmet går videre
                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                case "4": // Hvis variablen "valg" er = 4 går programmet hertil og kører koden herunder
                    Console.Clear(); // Rydder konsolvinduet
                    Console.SetCursorPosition(48, 13); // Sætter en position for markøren
                    Console.Write("TILLYKKE DU HAR VUNDET"); // Udskriver en tekst
                    Console.ReadKey(); // Venter på et tastetryk før programmet går videre
                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                case "5": // Hvis variablen "valg" er = 5 går programmet hertil og kører koden herunder
                    Console.Clear(); // Rydder konsolvinduet
                    Console.Write("Du har tastet: " + valg); // Udskriver en tekst + værdien på variablen
                    Console.ReadKey(); // Venter på et tastetryk før programmet går videre
                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                case "6": // Hvis variablen "valg" er = 6 går programmet hertil og kører koden herunder
                    Console.Clear(); // Rydder konsolvinduet
                    Console.Write("Du har tastet: " + valg); // Udskriver en tekst + værdien på variablen
                    Console.ReadKey(); // Venter på et tastetryk før programmet går videre
                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                default: // Hvis den værdi der bliver angivet til variablen der styrer vores switch, vil programmet køre default
                    Console.Clear(); // Rydder konsolvinduet
                    Console.Write("Du har tastet forkert. Tallet skal være mellem 1 & 6!\nProgrammet fortsætter om 10 sekunder."); // Udskriver en tekst
                    System.Threading.Thread.Sleep(10000); // Sætter programmet til at pause alle handlinger i 10 sekunder
                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
            }

        }
        static void Switch2() // Laver en metode der returnerer alt kode
        {
            string drink; // Erklærer en variabel uden værdi
            do //Starter et do-while loop
            {
                Console.Clear(); // Rydder konsolvinduet
                int isbj = 1, champ = 99, tequ = 299000, moji = 123, bran = 1991, filu = 69; // Erklærer 6 variabler med værdierne 1, 99, 299000, 123, 1991 og 69
                Console.Write("1. Isbjørn\n2. Champagnebrus\n3. Tequila Sunrise\n4. Mojito\n5. Brandbil\n6. Filur\nVælg en drink: "); // Udskriver en tekst
                drink = Console.ReadLine(); // Programmet spørger efter en indtastning og overfører værdien man indtaster til string variablen "drink"
                switch (drink) //Laver en switch der arbejder ud fra variablen "drink"
                {
                    case "1": // Hvis variablen "drink" er = 1 går programmet hertil og kører koden herunder
                        Console.Clear(); // Rydder konsolvinduet
                        Console.Write("Du har valgt en isbjørn til prisen: " + isbj + " kr."); // Udskriver en tekst + værdien på variablen
                        Console.ReadKey(); // Venter på et tastetryk før programmet går videre
                        break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                    case "2": // Hvis variablen "drink" er = 2 går programmet hertil og kører koden herunder
                        Console.Clear(); // Rydder konsolvinduet
                        Console.Write("Du har valgt en champagnebrus til prisen: " + champ + " kr."); // Udskriver en tekst + værdien på variablen
                        Console.ReadKey(); // Venter på et tastetryk før programmet går videre
                        break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                    case "3": // Hvis variablen "drink" er = 3 går programmet hertil og kører koden herunder
                        Console.Clear(); // Rydder konsolvinduet 
                        Console.Write("Du har valgt en tequila sunrise til prisen: " + tequ + " kr."); // Udskriver en tekst + værdien på variablen
                        Console.ReadKey(); // Venter på et tastetryk før programmet går videre
                        break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                    case "4": // Hvis variablen "drink" er = 4 går programmet hertil og kører koden herunder
                        Console.Clear(); // Rydder konsolvinduet
                        Console.Write("Du har valgt en mojito til prisen: " + moji + " kr."); // Udskriver en tekst + værdien på variablen
                        Console.ReadKey(); // Venter på et tastetryk før programmet går videre
                        break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                    case "5": // Hvis variablen "drink" er = 5 går programmet hertil og kører koden herunder
                        Console.Clear(); // Rydder konsolvinduet
                        Console.Write("Du har valgt en brandbil til prisen: " + bran + " kr."); // Udskriver en tekst + værdien på variablen
                        Console.ReadKey(); // Venter på et tastetryk før programmet går videre
                        break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                    case "6": // Hvis variablen "drink" er = 6 går programmet hertil og kører koden herunder
                        Console.Clear(); // Rydder konsolvinduet
                        Console.Write("Du har valgt en filur til prisen: " + filu + " kr."); // Udskriver en tekst + værdien på variablen
                        Console.ReadKey(); // Venter på et tastetryk før programmet går videre
                        break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                    default: // Hvis den værdi der bliver angivet til variablen der styrer vores switch, vil programmet køre default
                        Console.Clear(); // Rydder konsolvinduet
                        Console.Write("Du har unladt at vælge en drink, men der er ingen vej udenom alkoholen. Prøv igen."); // Udskriver en tekst
                        Console.ReadKey(); // Venter på et tastetryk før programmet går videre
                        break; // Bryder ud af switch-menuen, så den kun kører den valgte menu

                }
            } while (drink != "1" && drink != "2" && drink != "3" && drink != "4" && drink != "5" && drink != "6"); // Sender brugeren tilbage til starten af do-while loopet hvis variablen ikke er = 0
        }
        static void Loop1() // Laver en metode der returnerer alt kode
        {
            int i; // Erklærer variablen "i" uden en værdi
            Console.Clear(); // Rydder konsolvinduet
            for (i = 1; i < 11; i++) // Laver et for-loop der angiver "i"s værdi til 1, vil køre så længe variablen "i" er mindre end 11, og vil øge værdien af "i" med 1 hver gang den looper
            {
                Console.WriteLine(i); // Udskriver værdien af variablen
            }
            Console.ReadKey(); // Venter på et tastetryk før programmet går videre
            i = 1; // Sætter værdien af "i" til 1
            while (i < 11) // Et while-loop der kører så længe variablen "i" er mindre end 11
            {
                Console.WriteLine(i); // Udskriver værdien af variablen
                i = i + 1; // Forøger værdien af "i" med 1 hver gang while-loopet kører
            }
            Console.ReadKey(); // Venter på et tastetryk før programmet går videre
        }
        static void Loop2() // Laver en metode der returnerer alt kode
        {
            Console.Clear(); // Rydder konsolvinduet
            int i; // Erklærer variablen "i" uden en værdi
            for (i = 100; i > 0; i--) // Laver et for-loop der angiver "i"s værdi til 100, vil køre så længe variablen "i" er større end 0, og vil mindske værdien af "i" med 1 hver gang den looper
            {
                Console.WriteLine(i); // Udskriver værdien af variablen
            }
            Console.ReadKey(); // Venter på et tastetryk før programmet går videre
            i = 100; // Sætter værdien af "i" til 100
            while (i > 0) // Et while-loop der kører så længe variablen "i" er større end 0
            {
                Console.WriteLine(i); // Udskriver værdien af variablen
                i -= 1; // Formindsker værdien af "i" med 1 hver gang while-loopet kører
            }
            Console.ReadKey(); // Venter på et tastetryk før programmet går videre
        }
        static void Loop3() // Laver en metode der returnerer alt kode
        {
            Console.Clear(); // Rydder konsolvinduet
            for (int i = 5; i < 51; i = i + 5) // Laver et for-loop der angiver "i"s værdi til 5, vil køre så længe variablen "i" er mindre end 51, og vil øge værdien af "i" med 5 hver gang den looper
            {
                Console.WriteLine(i); // Udskriver værdien af variablen
            }
            Console.ReadKey(); // Venter på et tastetryk før programmet går videre
        }
        static void Loop4() // Laver en metode der returnerer alt kode
        {
            Console.Clear(); // Rydder konsolvinduet
            int i; // Erklærer variablen "i" uden en værdi
            Console.Clear(); // Rydder konsolvinduet
            for (i = 20; i > -1; i--) // Laver et for-loop der angiver "i"s værdi til 20, vil køre så længe variablen "i" er større end -1, og vil mindske værdien af "i" med 1 hver gang den looper
            {
                Console.WriteLine(i); // Udskriver værdien af variablen
            }
            Console.ReadKey(); // Venter på et tastetryk før programmet går videre
            i = 20; // Sætter værdien af "i" til 20
            while (i > -1) // Et while-loop der kører så længe variablen "i" er større end -1
            {
                Console.WriteLine(i); // Udskriver værdien af variablen
                i = i - 1; // Formindsker værdien af "i" med 1 hver gang while-loopet kører
            }
            Console.ReadKey(); // Venter på et tastetryk før programmet går videre
        }
        static void Loop5() // Laver en metode der returnerer alt kode
        {
            Console.Clear(); // Rydder konsolvinduet
            for (int i = 1; i < 11; i++) // Laver et for-loop der angiver "i"s værdi til 1, vil køre så længe variablen "i" er mindre end 11, og vil øge værdien af "i" med 1 hver gang den looper
            {
                int x = i * 7; // Erklærer variablen x som gemmer værdien af variablen "i" * 7
                if (i == 10) // Et if statement der kører koden herunder hvis dets parametrer er sande
                {
                    Console.WriteLine(i + " * 7 = {0,3}", x); // Udskriver en tekst med værdien af variablerne der er indekseret
                }
                else // Et else statement der kører koden herunder hvis ingen if/else-if statements er sande
                {
                    Console.WriteLine(i + " * 7 = {0,4}", x); // Udskriver en tekst med værdien af variablerne der er indekseret
                }
            }
            Console.ReadKey(); // Venter på et tastetryk før programmet går videre
        }
        static void Loop6() // Laver en metode der returnerer alt kode
        {
            Console.Clear(); // Rydder konsolvinduet
            Console.Write("Indtast den ønskede tabel: "); // Udskriver en tekst
            int x = int.Parse(Console.ReadLine()); // Programmet spørger efter en indtastning og overfører værdien man indtaster til string variablen "x".
            Console.Clear(); // Rydder konsolvinduet
            for (int i = 1; i < 11; i++) // Laver et for-loop der angiver "i"s værdi til 1, vil køre så længe variablen "i" er mindre end 11, og vil øge værdien af "i" med 1 hver gang den looper
            {

                int y = i * x; // Erklærer variablen x som gemmer værdien af variablen "i" * "x"
                if (i == 10) // Et if statement der kører koden herunder hvis dets parametrer er sande
                {
                    Console.WriteLine(i + " * {0} = {1,9}", x, y); // Udskriver en tekst med værdien af variablerne der er indekseret
                }
                else // Et else statement der kører koden herunder hvis ingen if/else-if statements er sande
                {
                    Console.WriteLine(i + " * {0} = {1,10}", x, y); // Udskriver en tekst med værdien af variablerne der er indekseret
                }
            }
            Console.ReadKey(); // Venter på et tastetryk før programmet går videre
        }
        static void Loop7() // Laver en metode der returnerer alt kode
        {
            Console.Clear(); // Rydder konsolvinduet
            for (int x1 = 20; x1 < 31; x1++) // Laver et for-loop der angiver "x1"s værdi til 20, vil køre så længe variablen "x1" er mindre end 31, og vil øge værdien af "x1" med 1 hver gang den looper
            {
                Console.SetCursorPosition(x1, 4); // Sætter positionen af markøren
                Console.Write("#"); // Udskriver en tekst
                Console.SetCursorPosition(x1, 8); // Sætter positionen af markøren
                Console.Write("#"); // Udskriver en tekst
            }
            for (int y = 4; y < 9; y++) // Laver et for-loop der angiver "y"s værdi til 4, vil køre så længe variablen "y" er mindre end 9, og vil øge værdien af "y" med 1 hver gang den looper
            {
                Console.SetCursorPosition(20, y); // Sætter positionen af markøren
                Console.Write("#"); // Udskriver en tekst
                Console.SetCursorPosition(30, y); // Sætter positionen af markøren
                Console.Write("#"); // Udskriver en tekst
            }
            Console.ReadKey(); // Venter på et tastetryk før programmet går videre
        }
        static void Loop8() // Laver en metode der returnerer alt kode
        {
            Console.Clear(); // Rydder konsolvinduet
            for (int x1 = 20; x1 < 31; x1++) // Laver et for-loop der angiver "x1"s værdi til 20, vil køre så længe variablen "x1" er mindre end 31, og vil øge værdien af "x1" med 1 hver gang den looper
            {
                Console.SetCursorPosition(x1, 4); // Sætter positionen af markøren
                Console.Write("#"); // Udskriver en tekst
                Console.SetCursorPosition(x1, 8); // Sætter positionen af markøren
                Console.Write("#"); // Udskriver en tekst
            }
            for (int y = 4; y < 9; y++) // Laver et for-loop der angiver "y"s værdi til 4, vil køre så længe variablen "y" er mindre end 9, og vil øge værdien af "y" med 1 hver gang den looper
            {
                Console.SetCursorPosition(20, y); // Sætter positionen af markøren
                Console.Write("#"); // Udskriver en tekst
                Console.SetCursorPosition(30, y); // Sætter positionen af markøren
                Console.Write("#"); // Udskriver en tekst
            }
            Console.SetCursorPosition(22, 6); // Sætter positionen af markøren
            Console.Write("Nicklas"); // Udskriver en tekst
            Console.ReadKey(); // Venter på et tastetryk før programmet går videre
        }
        static void Loop9() // Laver en metode der returnerer alt kode
        {
            Console.Clear();
            Console.Write("Hvor langt hen af X'aksen skal rammen være? (Mindst: 10 - Max: 119): "); // Udskriver en tekst
            int xakse = int.Parse(Console.ReadLine()); // Programmet spørger efter en indtastning og overfører værdien man indtaster til string variablen "xakse"
            Console.Write("Hvor langt ned af Y'aksen skal rammen være? (Mindst: 2 - Max: 28): "); // Udskriver en tekst
            int yakse = int.Parse(Console.ReadLine()); // Programmet spørger efter en indtastning og overfører værdien man indtaster til string variablen "yakse"
            Console.Write("Indtast navn: "); // Udskriver en tekst
            string navn = Console.ReadLine(); // Programmet spørger efter en indtastning og overfører værdien man indtaster til string variablen "navn"
            int length = navn.Count(); // Erklærer en variabel der gemmer værdien af antallet af bogstaver i variablen "navn"
            Console.Clear(); // Rydder konsolvinduet
            for (int x = 0; x < xakse + 1; x++) // Laver et for-loop der angiver "x"s værdi til 0, vil køre så længe variablen "x" er mindre end ("xakse" + 1), og vil øge værdien af "x" med 1 hver gang den looper
            {
                if (xakse > 119 || xakse < 10 || yakse < 2 || yakse > 28) // Et if statement der kører koden herunder hvis dets parametrer er sande
                {
                    Console.Write("Dit tal på X-aksen skal være mellem 10 og 119!\nDit tal på Y-aksen skal være mellem 2 og 28!"); // Udskriver en tekst
                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                }
                else // Et else statement der kører koden herunder hvis ingen if/else-if statements er sande
                {
                    Console.SetCursorPosition(x, 0); // Sætter positionen af markøren
                    Console.Write("#"); // Udskriver en tekst
                    Console.SetCursorPosition(x, yakse); // Sætter positionen af markøren
                    Console.Write("#"); // Udskriver en tekst
                }

            }
            for (int y = 0; y < yakse; y++) // Laver et for-loop der angiver "y"s værdi til 0, vil køre så længe variablen "y" er mindre end "yakse", og vil øge værdien af "y" med 1 hver gang den looper
            {
                if (yakse < 2 || yakse > 28 || xakse > 119 || xakse < 10) // Et if statement der kører koden herunder hvis dets parametrer er sande
                {
                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                }
                else // Et else statement der kører koden herunder hvis ingen if/else-if statements er sande
                {
                    Console.SetCursorPosition(0, y); // Sætter positionen af markøren
                    Console.Write("#"); // Udskriver en tekst
                    Console.SetCursorPosition(xakse, y); // Sætter positionen af markøren
                    Console.Write("#"); // Udskriver en tekst
                }
            }
            if (yakse >= 2 && yakse <= 28 && xakse <= 119 && xakse >= 10) // Et if statement der kører koden herunder hvis dets parametrer er sande
            {
                double xakseNavn = xakse * 0.5 - length * 0.5; // Erklærer 1 variabel med værdien "xakse" + 0,5 - "length" * 0,5 
                double yakseNavn = yakse * 0.5; // Erklærer 1 variabel med værdien yakse * 0,5
                Console.SetCursorPosition(Convert.ToInt32(xakseNavn), Convert.ToInt32(yakseNavn)); // Sætter positionen af markøren
                Console.Write(navn); // Udskriver værdien af variablen
            }
            Console.ReadKey(); // Venter på et tastetryk før programmet går videre
        }
        static void Udkons1() // Laver en metode der returnerer alt kode
        {
            Console.Clear(); // Rydder konsolvinduet
            for (int i = 3; i < 31; i = i + 3)  // Laver et for-loop der angiver "i"s værdi til 3, vil køre så længe variablen "i" er mindre end 31, og vil øge værdien af "i" med 3 hver gang den looper
            {
                if (i == 21) // Et if statement der kører koden herunder hvis dets parametrer er sande
                {
                    Console.Write("Loopet er nu stoppet."); // Udskriver en tekst
                    break; // Bryder ud af switch-menuen, så den kun kører den valgte menu
                }
                Console.WriteLine(i); // Udskriver værdien af variablen
            }
            Console.ReadKey(); // Venter på et tastetryk før programmet går videre
        }
        static void Udkons2() // Laver en metode der returnerer alt kode
        {
            Console.Clear(); // Rydder konsolvinduet
            int i = 4; // Erklærer en variabel med værdien 4
            while (i < 41) // Et while-loop der kører så længe variablen "i" er mindre end 41
            {
                if (i == 16) // Et if statement der kører koden herunder hvis dets parametrer er sande
                {
                    i = i + 4; // Vil øge variablen "i"s værdi med 4 for hvert loop
                }
                Console.WriteLine(i); // Udskriver værdien af "i"
                i = i + 4; // Vil øge variablen "i"s værdi med 4 for hvert loop
            }
            Console.Write("Loopet er nu stoppet."); // Udskriver en tekst
            Console.ReadKey(); // Venter på et tastetryk før programmet går videre
        }
        static void Udkons3() // Laver en metode der returnerer alt kode
        {
            Console.Clear(); // Rydder konsolvinduet
            Console.WriteLine("Indtast distance kørt hver dag til og fra arbejde i km: "); // Udskriver en tekst
            double distance = double.Parse(Console.ReadLine()); // Programmet spørger efter en indtastning og overfører værdien man indtaster til string variablen "distance"
            if (distance > 0 && distance <= 24) // Et if statement der kører koden herunder hvis dets parametrer er sande
            {
                Console.Clear(); // Rydder konsolvinduet
                Console.WriteLine("Du får ikke noget fradrag."); // Udskriver en tekst
            }
            else if (distance > 24 && distance <= 100) // Et else if statement der kører koden herunder hvis dets parametrer er sande, så længe det første statement ikke var sandt
            {
                Console.Clear(); // Rydder konsolvinduet
                double fradrag1 = (distance - 24) * 1.54; // Erklærer en variabel med værdien (distance - 24) * 1,54
                Console.Write("Da du har {0} km til og fra arbejde får du {1} kr i fradrag!", distance, fradrag1); // Udskriver en tekst med værdien af variablerne der er indekseret
            }
            else if (distance > 120 && distance <= 500) // Et else if statement der kører koden herunder hvis dets parametrer er sande, så længe det første statement ikke var sandt
            {
                Console.Clear(); // Rydder konsolvinduet
                double fradrag2 = 75 * 1.54 + (distance - 100) * 0.77; // Erklærer en variabel med værdien (distance - 100) * 0,77
                Console.Write("Da du har {0} km til og fra arbejde får du {1} kr i fradrag!", distance, fradrag2); // Udskriver en tekst med værdien af variablerne der er indekseret
            }
            if (distance < 1 || distance > 500) // Et if statement der kører koden herunder hvis dets parametrer er sande
            {
                Console.Clear(); // Rydder konsolvinduet
                Console.Write("Distancen er ugyldig og skal være mellem 1 og 500 km"); // Udskriver en tekst
            }
            Console.ReadKey(); // Venter på et tastetryk før programmet går videre
        }
        static void Udkons4() // Laver en metode der returnerer alt kode
        {
            Console.Clear(); // Rydder konsolvinduet
            Console.Write("Indtast din årlige indkomst: "); // Udskriver en tekst
            double indkomst = double.Parse(Console.ReadLine()); // Programmet spørger efter en indtastning og overfører værdien man indtaster til string variablen "distance"
            double bundskat = 0.30, mellemskat = 0.06, topskat = 0.15, skat; // Erklærer fire variabler med værdierne 0,30 - 0,06 - 0,15 og ingen værdi

            if (indkomst < 42000 && indkomst > 0) // Et if statement der kører koden herunder hvis dets parametrer er sande
            {
                Console.Clear(); // Rydder konsolvinduet
                Console.Write("Når din indkomst er under 42.000kr skal du ikke betale skat."); // Udskriver en tekst
            }
            else if (indkomst >= 42000 && indkomst < 280000) // Et else if statement der kører koden herunder hvis dets parametrer er sande, så længe det første statement ikke var sandt
            {
                skat = indkomst * bundskat; // Giver variablen "skat" en værdi der er = "indkomst" * "bundskat"
                Console.Clear(); // Rydder konsolvinduet
                Console.Write("Når din indkomst er {0:0.00}kr skal du betale 30% i bundskat." +
                    "\nDerfor er det samlede beløb du skal betale i skat = {1:0.00}kr.", indkomst, skat);  // Udskriver en tekst med værdien af variablerne der er indekseret
            }
            else if (indkomst >= 280000 && indkomst < 390000) // Et else if statement der kører koden herunder hvis dets parametrer er sande, så længe det første statement ikke var sandt
            {
                skat = 280000 * bundskat + (indkomst - 280000) * mellemskat; // Giver variablen "skat" en værdi der er = 280000 * "bundskat" + ("indkomst" - 280000) * "mellemskat"
                Console.Clear(); // Rydder konsolvinduet
                Console.Write("Når din indkomst er {0:0.00}kr skal du betale 30% i bundskat af 280.000kr" +
                    " og 6% mellemskat af resten." +
                    "\nDerfor er det samlede beløb du skal betale i skat = {1:0.00}kr.", indkomst, skat); // Udskriver en tekst med værdien af variablerne der er indekseret
            }
            else if (indkomst >= 390000) // Et else if statement der kører koden herunder hvis dets parametrer er sande, så længe det første statement ikke var sandt
            {
                skat = 280000 * bundskat + 110000 * mellemskat + (indkomst - 390000) * topskat; // Giver variablen "skat" en værdi der er = 280000 * "bundskat" + 110000 * "mellemskat" + ("indkomst" - 390000) * "topskat"
                Console.Clear(); // Rydder konsolvinduet
                Console.Write("Når din indkomst er {0:0.00}kr skal du betale 30% i bundskat af 280.000kr," +
                    " 6% mellemskat af 110.000kr og 15% topskat af resten." +
                    "\nDerfor er det samlede beløb du skal betale i skat = {1:0.00}kr.", indkomst, skat); // Udskriver en tekst med værdien af variablerne der er indekseret
            }
            else // Et else statement der kører koden herunder hvis ingen if/else-if statements er sande
            {
                Console.Clear(); // Rydder konsolvinduet
                Console.WriteLine("Din indtastning skal være over 0 kr"); // Udskriver en tekst
            }
            Console.ReadKey(); // Venter på et tastetryk før programmet går videre
        }
        static void Udkons5() // Laver en metode der returnerer alt kode
        {
            Console.Clear(); // Rydder konsolvinduet
            Console.Write("Indtast beløb indestående på bankkonto: "); // Udskriver en tekst 
            double beløb = double.Parse(Console.ReadLine()); // Programmet spørger efter en indtastning og overfører værdien man indtaster til string variablen "beløb"
            double rente; // Erklærer en variabel uden værdi
            if (beløb < 25000 && beløb > 0) // Et if statement der kører koden herunder hvis dets parametrer er sande
            {
                rente = beløb * 0.0025; // Ændrer værdien af variablen så den er = "beløb" * 0,0025
                Console.Write("Ud af de {0}kr du har i banken, får du {1:0.00}kr i rente per år.", beløb, rente); // Udskriver en tekst med værdien af variablerne der er indekseret
            }
            else if (beløb >= 25000 && beløb < 150000) // Et else if statement der kører koden herunder hvis dets parametrer er sande, så længe det første statement ikke var sandt
            {
                rente = beløb * 0.0125; // Ændrer værdien af variablen så den er = "beløb" * 0,0125
                Console.Write("Ud af de {0}kr du har i banken, får du {1:0.00}kr i rente per år.", beløb, rente); // Udskriver en tekst med værdien af variablerne der er indekseret
            }
            else if (beløb >= 150000) // Et else if statement der kører koden herunder hvis dets parametrer er sande, så længe det første statement ikke var sandt
            {
                rente = 150000 * 0.0125 + (beløb - 150000) * 0.005; // Ændrer værdien af variablen så den er = 150.000 * 0.0125 + ("beløb" - 150.000) * 0,005
                Console.Write("Ud af de {0}kr du har i banken, får du {1:0.00}kr i rente per år.", beløb, rente); // Udskriver en tekst med værdien af variablerne der er indekseret
            }
            else // Et else statement der kører koden herunder hvis ingen if/else-if statements er sande
            {
                Console.Clear(); // Rydder konsolvinduet
                Console.WriteLine("Din indtastning skal være over 0 kr"); // Udskriver en tekst
            }
            Console.ReadKey(); // Venter på et tastetryk før programmet går videre
        }
        static void Array1() // Laver en metode der returnerer alt kode
        {
            Console.Clear(); // Rydder konsolvinduet
            int[] array = { -2, -1, 0, 10 }; // Laver et array af variabler med værdierne: -2, -1, 0 og 10
            int[] array2 = new int[4]; // Laver et array af 4 variabler uden værdier
            array2[0] = -2; // Sætter værdian af array2[0] til -2
            array2[1] = -1; // Sætter værdian af array2[1] til -1
            array2[2] = 0; // Sætter værdian af array2[2] til 0
            array2[3] = 10; // Sætter værdian af array2[3] til 10

            int arraySum = array.Sum(); // Erklærer en variabel der har værdien af summen af array
            int arraySum2 = array2.Sum(); // Erklærer en variabel der har værdien af summen af array2

            Console.Write("Sum of array #1: {0}\nSum of array #2: {1}", arraySum, arraySum2); // Udskriver en tekst med værdien af variablerne der er indekseret
            Console.ReadKey(); // Venter på et tastetryk før programmet går videre
        }
        static void Array2() // Laver en metode der returnerer alt kode
        {
            Console.Clear(); // Rydder konsolvinduet
            int[] array = { -10, -5, 0, 10, 156, 1000 }; // Laver et array af variabler med værdierne: -10, -5, 0, 10, 156 og 1000

            int arraySum = 0; // Erklærer en variabel med værdien 0
            for (int i = 0; i < 6; i++) // Laver et for-loop der angiver "i"s værdi til 0, vil køre så længe variablen "i" er mindre end 6, og vil øge værdien af "i" med 1 hver gang den looper
            {
                arraySum = arraySum + array[i]; // Tilføjer værdien af hver enkelt array hvert loop, så vi til sidst har summen
            }

            Console.Write(arraySum); // Udskriver værdien af variablen

            Console.ReadKey(); // Venter på et tastetryk før programmet går videre
        }
    }
}

