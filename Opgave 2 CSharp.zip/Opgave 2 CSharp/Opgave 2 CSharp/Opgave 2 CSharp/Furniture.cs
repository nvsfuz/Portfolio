﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_2_CSharp
{
    public class Furniture
    {
        public static void FurnitureMain() // Hovedprogrammet
        {
            Console.Clear(); // Rydder konsolvinduet
            Chair myChair = new Chair(); // Laver et nyt objekt af Furniture-klassen
            myChair.Make = "Aspen"; // Angiver en variabel til myChair objektet
            myChair.Height = 90; // Angiver en variabel til myChair objektet
            myChair.Material = "plastic"; // Angiver en variabel til myChair objektet

            Computer myComputer = new Computer();
            myComputer.Make = "Lenovo"; // Angiver en variabel til myComputer objektet
            myComputer.OS = "Windows 10"; // Angiver en variabel til myComputer objektet
            myComputer.RAM = 16307; // Angiver en variabel til myComputer objektet
            myComputer.Processor = "Intel(R) Core(TM) i5-4570 CPU @ 3.20GHz"; // Angiver en variabel til myComputer objektet

            Console.Write("How much money do you have available?: "); //Udskriver en tekst
            int myMoney = Convert.ToInt32(Console.ReadLine()); // Programmet spørger efter en indtastning og overfører værdien man indtaster til string variablen "myMoney"

            bool chairAfford = canAfford(myMoney, ChairPrice), computerAfford = canAfford(myMoney, ComputerPrice); // Angiver 2 bool variabler der giver en true/false værdi
            string chairAffordString, computerAffordString; // Angiver 2 variabler uden værdier
            if (chairAfford == true) // Et if statement der kører koden herunder hvis dets parametrer er sande
            {
                chairAffordString = "I can afford this!"; // Udskriver en tekst
            }
            else chairAffordString = "I can't afford this!"; // Et else statement der køres hvis if statement ikke er sandt - Udskriver en tekst
            if (computerAfford == true) // Et if statement der kører koden herunder hvis dets parametrer er sande
            {
                computerAffordString = "I can afford this!"; // Udskriver en tekst
            }
            else computerAffordString = "I can't afford this!"; // Et else statement der køres hvis if statement ikke er sandt - Udskriver en tekst

            Console.Clear(); // Rydder konsolvinduet
            Console.WriteLine("<Min stol>\nMake: {0}\nHeight: {1}cm\nMaterial: {2}\n\nPrice: {3}\n{4}\n\n<Min computer>\nMake: {5}\nOS: {6}\nRAM: {7}\nProcessor: {8}\n\nPrice: {9}\n{10}", 
               myChair.Make,
               myChair.Height,
               myChair.Material,
               ChairPrice,
               chairAffordString,
               myComputer.Make,
               myComputer.OS,
               myComputer.RAM,
               myComputer.Processor,
               ComputerPrice,
               computerAffordString); // Udskriver en tekst efterfulgt af værdierne af de indekserede variabler.
            Console.ReadKey(); // Venter på et tastetryk før programmet går videre

        }
        static int ChairPrice = 15000; // Erklærer en instans variabel med værdien 15.000
        static int ComputerPrice = 9000; // Erklærer en instans variabel med værdien 9.000
        static bool canAfford(int myMoney, int price) // Laver en metode der returner en true/false værdi
        {
            if (myMoney >= price) // Et if statement der kører koden herunder hvis dets parametrer er sande
            {
                return true; // Returnerer true til metoden
            }
            else return false; // Et else statement der køres hvis if statement ikke er sandt - Returnerer False til metoden
        }
    }
    public class Chair : Furniture // Laver en sub-class kaldet "Chair" under class "Furniture"
    {
        public string Make { get; set; } // Laver en metode der henter og returnerer en værdi
        public int Height { get; set; } // Laver en metode der henter og returnerer en værdi
        public string Material { get; set; } // Laver en metode der henter og returnerer en værdi
    }
    public class Computer : Furniture // Laver en sub-class kaldet "Computer" under class "Furniture"
    {
        
        public string Make { get; set; } // Laver en metode der henter og returnerer en værdi
        public string OS { get; set; } // Laver en metode der henter og returnerer en værdi
        public int RAM { get; set; } // Laver en metode der henter og returnerer en værdi
        public string Processor { get; set; } // Laver en metode der henter og returnerer en værdi
    }

}
