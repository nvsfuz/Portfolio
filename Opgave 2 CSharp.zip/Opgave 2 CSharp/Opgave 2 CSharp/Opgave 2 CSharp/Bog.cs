﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_2_CSharp
{
    class Bog
    {
        public static void MainBog() // Hovedprogrammet
        {
            Console.Clear(); // Rydder konsolvinduet
            Bog SherlockHolmes = new Bog(); // Laver et nyt objekt af Bog-klassen
            SherlockHolmes.PrintInfo(); // Udskriver objektet "SherlockHolmes" med koden i metoden "PrintInfo"

            Bog MobyDick = new Bog(); // Laver et nyt objekt af Bog-klassen
            {
                PrisGet; // Tildeler "MobyDick" en variabel med værdien 240
                TitelGet; // Tildeler "MobyDick" en variabel med værdien "Moby Dick"
            };

            Console.WriteLine("{0} - Koster {1} kr.", , MobyDick.PrisGet); // Udskriver en tekst efterfulgt af værdien af den indekserede variabel.

            Console.Write("Hvor mange penge har du?: "); // Udskriver en tekst
            int minePenge = int.Parse(Console.ReadLine()); // Programmet spørger efter en indtastning og overfører værdien man indtaster til string variablen "minePenge"

            bool sherlockRåd = SherlockHolmes.HarRåd(minePenge); // Erklærer en ny variabel med værdien false/true

            if (sherlockRåd == true) // Et if statement der kører koden herunder hvis dets parametrer er sande
            {
                Console.Write("Jeg har råd!"); // Udskriver en tekst
            }
            else Console.Write("Jeg har ikke råd!"); // Et else statement der køres hvis if statement ikke er sandt - Returnerer false til metoden

            Console.ReadKey(); // Venter på et tastetryk før programmet går videre
        }
        public int PrisGetIns; // Erklærer en instansvariabel uden værdi
        public String TitelGetIns; // Erklærer en instansvariabel uden værdi
        static int PrisGet // Erklærer en metode der returnerer en værdi
        {
            get { return this.PrisGetIns; } // Giver metoden besked på at den skal returnere den endelig værdi til variablen "PrisGetIns"
            set { this.PrisGetIns = 240; } // Forklarer metoden hvilken værdi der skal returneres
        }
        public string TitelGet
        {
            get { return this.TitelGetIns; } // Giver metoden besked på at den skal returnere den endelig værdi til variablen "TitelGetIns"
            set { this.TitelGetIns = "Moby Dick"; } // Forklarer metoden hvilken værdi der skal returneres
        }
        public bool HarRåd(int x) // Laver en metode der returnerer et true/false statement
        {
            if (x >= 150) // Et if statement der kører koden herunder hvis dets parametrer er sande
            {
                return true; // Returnerer true til metoden
            }
            else return false; // Et else statement der køres hvis if statement ikke er sandt - Returnerer false til metoden
        }
        public void PrintInfo() // Laver en metode der returnerer alt kode
        {
            Console.WriteLine("Jeg er en bog"); // Udskriver en tekst
            Console.ReadKey(); // Venter på et tastetryk før programmet går videre
        }
        int Pris = 240; // Erklærer en instans variabel med værdien 240
        string Titel = "Karl Mars Eventyr"; // Erklærer en instans variabel med værdien "Karl Mars Eventyr"
        public Bog() // En konstruktor 
        {
            Console.Write(Pris + " " + Titel + " | "); // Udskriver en tekst og værdien af variablerne
        }


    }
}
